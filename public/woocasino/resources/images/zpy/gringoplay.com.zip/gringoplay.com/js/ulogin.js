! function(t, i, e, n) {
    var o;
    void 0 === t.easyXDM && function(t, i, n, o, s, r) {
        function a(t, i) {
            var e = typeof t[i];
            return "function" == e || !("object" != e || !t[i]) || "unknown" == e
        }

        function d() {
            if (!p(e.plugins) && "object" == typeof e.plugins["Shockwave Flash"]) {
                var t = e.plugins["Shockwave Flash"].description;
                t && !p(e.mimeTypes) && e.mimeTypes["application/x-shockwave-flash"] && e.mimeTypes["application/x-shockwave-flash"].enabledPlugin && (w = t.match(/\d+/g))
            }
            if (!w) try {
                var i = new ActiveXObject("ShockwaveFlash.ShockwaveFlash");
                w = Array.prototype.slice.call(i.GetVariable("$version").match(/(\d+),(\d+),(\d+),(\d+)/), 1)
            } catch (t) {}
            return !!w && (t = parseInt(w[0], 10), i = parseInt(w[1], 10), L = 9 < t && 0 < i, !0)
        }

        function l() {
            if (!I) {
                I = !0;
                for (var t = 0; t < P.length; t++) P[t]();
                P.length = 0
            }
        }

        function c(t, i) {
            I ? t.call(i) : P.push(function() {
                t.call(i)
            })
        }

        function h(t) {
            var i = t.toLowerCase().match(S);
            t = i[2];
            var e = i[3];
            return i = i[4] || "", ("http:" == t && ":80" == i || "https:" == t && ":443" == i) && (i = ""), t + "//" + e + i
        }

        function u(t) {
            if (!(t = t.replace(A, "$1/")).match(/^(http||https):\/\//)) {
                var i = "/" === t.substring(0, 1) ? "" : n.pathname;
                "/" !== i.substring(i.length - 1) && (i = i.substring(0, i.lastIndexOf("/") + 1)), t = n.protocol + "//" + n.host + i + t
            }
            for (; C.test(t);) t = t.replace(C, "");
            return t
        }

        function g(t, i) {
            var e = "",
                n = t.indexOf("#");
            for (var o in -1 !== n && (e = t.substring(n), t = t.substring(0, n)), n = [], i) i.hasOwnProperty(o) && n.push(o + "=" + r(i[o]));
            return t + (M ? "#" : -1 == t.indexOf("?") ? "?" : "&") + n.join("&") + e
        }

        function p(t) {
            return void 0 === t
        }

        function f(t, i, e) {
            var n;
            for (n in i)
                if (i.hasOwnProperty(n))
                    if (n in t) {
                        var o = i[n];
                        "object" == typeof o ? f(t[n], o, e) : e || (t[n] = i[n])
                    } else t[n] = i[n];
            return t
        }

        function m(t) {
            if (p(y)) {
                var e = i.body.appendChild(i.createElement("form")),
                    n = e.appendChild(i.createElement("input"));
                n.name = O + "TEST" + _, y = n !== e.elements[n.name], i.body.removeChild(e)
            }
            if (y ? e = i.createElement('<iframe name="' + t.props.name + '"/>') : (e = i.createElement("IFRAME")).name = t.props.name, e.id = e.name = t.props.name, delete t.props.name, "string" == typeof t.container && (t.container = i.getElementById(t.container)), t.container || (f(e.style, {
                    position: "absolute",
                    top: "-2000px",
                    left: "0px"
                }), t.container = i.body), n = t.props.src, t.props.src = "javascript:false", f(e, t.props), e.border = e.frameBorder = 0, e.allowTransparency = !0, t.container.appendChild(e), t.onLoad && R(e, "load", t.onLoad), t.usePost) {
                var o = t.container.appendChild(i.createElement("form"));
                if (o.target = e.name, o.action = n, o.method = "POST", "object" == typeof t.usePost)
                    for (var s in t.usePost)
                        if (t.usePost.hasOwnProperty(s)) {
                            if (y) var r = i.createElement('<input name="' + s + '"/>');
                            else(r = i.createElement("INPUT")).name = s;
                            r.value = t.usePost[s], o.appendChild(r)
                        }
                o.submit(), o.parentNode.removeChild(o)
            } else e.src = n;
            return t.props.src = n, e
        }

        function v(o) {
            var s = o.protocol;
            if (o.isHost = o.isHost || p(F.xdm_p), M = o.hash || !1, o.props || (o.props = {}), o.isHost) o.remote = u(o.remote), o.channel = o.channel || "default" + _++, o.secret = Math.random().toString(16).substring(2), p(s) && (s = h(n.href) == h(o.remote) ? "4" : a(t, "postMessage") || a(i, "postMessage") ? "1" : o.swf && a(t, "ActiveXObject") && d() ? "6" : "Gecko" === e.product && "frameElement" in t && -1 == e.userAgent.indexOf("WebKit") ? "5" : o.remoteHelper ? "2" : "0");
            else {
                var r;
                if (o.channel = F.xdm_c.replace(/["'<>\\]/g, ""), o.secret = F.xdm_s, o.remote = F.xdm_e.replace(/["'<>\\]/g, ""), s = F.xdm_p, r = o.acl) {
                    t: {
                        r = o.acl;
                        var l = o.remote;
                        "string" == typeof r && (r = [r]);
                        for (var c, m = r.length; m--;)
                            if (c = r[m], (c = new RegExp("^" == c.substr(0, 1) ? c : "^" + c.replace(/(\*)/g, ".$1").replace(/\?/g, ".") + "$")).test(l)) {
                                r = !0;
                                break t
                            }
                        r = !1
                    }
                    r = !r
                }
                if (r) throw Error("Access denied for " + o.remote)
            }
            switch (o.protocol = s, s) {
                case "0":
                    if (f(o, {
                            interval: 100,
                            delay: 2e3,
                            useResize: !0,
                            useParent: !1,
                            usePolling: !1
                        }, !0), o.isHost) {
                        if (!o.local) {
                            s = n.protocol + "//" + n.host;
                            var v = i.body.getElementsByTagName("img");
                            for (l = v.length; l--;)
                                if ((r = v[l]).src.substring(0, s.length) === s) {
                                    o.local = r.src;
                                    break
                                }
                            o.local || (o.local = t)
                        }
                        s = {
                            xdm_c: o.channel,
                            xdm_p: 0
                        }, o.local === t ? (o.usePolling = !0, o.useParent = !0, o.local = n.protocol + "//" + n.host + n.pathname + n.search, s.xdm_e = o.local, s.xdm_pa = 1) : s.xdm_e = u(o.local), o.container && (o.useResize = !1, s.xdm_po = 1), o.remote = g(o.remote, s)
                    } else f(o, {
                        channel: F.xdm_c,
                        remote: F.xdm_e,
                        useParent: !p(F.xdm_pa),
                        usePolling: !p(F.xdm_po),
                        useResize: !o.useParent && o.useResize
                    });
                    v = [new T.stack.HashTransport(o), new T.stack.ReliableBehavior({}), new T.stack.QueueBehavior({
                        encode: !0,
                        maxLength: 4e3 - o.remote.length
                    }), new T.stack.VerifyBehavior({
                        initiate: o.isHost
                    })];
                    break;
                case "1":
                    v = [new T.stack.PostMessageTransport(o)];
                    break;
                case "2":
                    o.isHost && (o.remoteHelper = u(o.remoteHelper)), v = [new T.stack.NameTransport(o), new T.stack.QueueBehavior, new T.stack.VerifyBehavior({
                        initiate: o.isHost
                    })];
                    break;
                case "3":
                    v = [new T.stack.NixTransport(o)];
                    break;
                case "4":
                    v = [new T.stack.SameOriginTransport(o)];
                    break;
                case "5":
                    v = [new T.stack.FrameElementTransport(o)];
                    break;
                case "6":
                    w || d(), v = [new T.stack.FlashTransport(o)]
            }
            return v.push(new T.stack.QueueBehavior({
                lazy: o.lazy,
                remove: !0
            })), v
        }

        function b(t) {
            for (var i, e = {
                    incoming: function(t, i) {
                        this.up.incoming(t, i)
                    },
                    outgoing: function(t, i) {
                        this.down.outgoing(t, i)
                    },
                    callback: function(t) {
                        this.up.callback(t)
                    },
                    init: function() {
                        this.down.init()
                    },
                    destroy: function() {
                        this.down.destroy()
                    }
                }, n = 0, o = t.length; n < o; n++) f(i = t[n], e, !0), 0 !== n && (i.down = t[n - 1]), n !== o - 1 && (i.up = t[n + 1]);
            return i
        }
        var y, w, L, k = this,
            _ = Math.floor(1e4 * Math.random()),
            x = Function.prototype,
            S = /^((http.?:)\/\/([^:\/\s]+)(:\d+)*)/,
            C = /[\-\w]+\/\.\.\//,
            A = /([^:])\/\//g,
            W = "",
            T = {},
            E = t.easyXDM,
            O = "easyXDM_",
            M = !1;
        if (a(t, "addEventListener")) var R = function(t, i, e) {
                t.addEventListener(i, e, !1)
            },
            N = function(t, i, e) {
                t.removeEventListener(i, e, !1)
            };
        else {
            if (!a(t, "attachEvent")) throw Error("Browser not supported");
            R = function(t, i, e) {
                t.attachEvent("on" + i, e)
            }, N = function(t, i, e) {
                t.detachEvent("on" + i, e)
            }
        }
        var I = !1,
            P = [];
        if ("readyState" in i) {
            var D = i.readyState;
            I = "complete" == D || ~e.userAgent.indexOf("AppleWebKit/") && ("loaded" == D || "interactive" == D)
        } else I = !!i.body;
        if (!I) {
            if (a(t, "addEventListener")) R(i, "DOMContentLoaded", l);
            else if (R(i, "readystatechange", function() {
                    "complete" == i.readyState && l()
                }), i.documentElement.doScroll && t === top) {
                var H = function() {
                    if (!I) {
                        try {
                            i.documentElement.doScroll("left")
                        } catch (t) {
                            return void o(H, 1)
                        }
                        l()
                    }
                };
                H()
            }
            R(t, "load", l)
        }
        var F = function(t) {
                for (var i, e = {}, n = (t = t.substring(1).split("&")).length; n--;) e[(i = t[n].split("="))[0]] = s(i[1]);
                return e
            }(/xdm_e=/.test(n.search) ? n.search : n.hash),
            U = function() {
                var t = {},
                    i = {
                        a: [1, 2, 3]
                    };
                return "undefined" != typeof JSON && "function" == typeof JSON.stringify && '{"a":[1,2,3]}' === JSON.stringify(i).replace(/\s/g, "") ? JSON : (Object.toJSON && '{"a":[1,2,3]}' === Object.toJSON(i).replace(/\s/g, "") && (t.stringify = Object.toJSON), "function" == typeof String.prototype.evalJSON && ((i = '{"a":[1,2,3]}'.evalJSON()).a && 3 === i.a.length && 3 === i.a[2] && (t.parse = function(t) {
                    return t.evalJSON()
                })), t.stringify && t.parse ? (U = function() {
                    return t
                }, t) : null)
            };
        f(T, {
                version: "2.4.19.0",
                query: F,
                stack: {},
                apply: f,
                getJSONObject: U,
                whenReady: c,
                noConflict: function(i) {
                    return t.easyXDM = E, (W = i) && (O = "easyXDM_" + W.replace(".", "_") + "_"), T
                }
            }), T.DomHelper = {
                on: R,
                un: N,
                requiresJSON: function(e) {
                    "object" == typeof t.JSON && t.JSON || i.write('<script type="text/javascript" src="' + e + '"><\/script>')
                }
            },
            function() {
                var t = {};
                T.Fn = {
                    set: function(i, e) {
                        t[i] = e
                    },
                    get: function(i, e) {
                        if (t.hasOwnProperty(i)) {
                            var n = t[i];
                            return e && delete t[i], n
                        }
                    }
                }
            }(), T.Socket = function(t) {
                var i = b(v(t).concat([{
                        incoming: function(i, e) {
                            t.onMessage(i, e)
                        },
                        callback: function(i) {
                            t.onReady && t.onReady(i)
                        }
                    }])),
                    e = h(t.remote);
                this.origin = h(t.remote), this.destroy = function() {
                    i.destroy()
                }, this.postMessage = function(t) {
                    i.outgoing(t, e)
                }, i.init()
            }, T.Rpc = function(t, i) {
                if (i.local)
                    for (var e in i.local)
                        if (i.local.hasOwnProperty(e)) {
                            var n = i.local[e];
                            "function" == typeof n && (i.local[e] = {
                                method: n
                            })
                        }
                var o = b(v(t).concat([new T.stack.RpcBehavior(this, i), {
                    callback: function(i) {
                        t.onReady && t.onReady(i)
                    }
                }]));
                this.origin = h(t.remote), this.destroy = function() {
                    o.destroy()
                }, o.init()
            }, T.stack.SameOriginTransport = function(t) {
                var i, e, s, r;
                return i = {
                    outgoing: function(t, i, e) {
                        s(t), e && e()
                    },
                    destroy: function() {
                        e && (e.parentNode.removeChild(e), e = null)
                    },
                    onDOMReady: function() {
                        r = h(t.remote), t.isHost ? (f(t.props, {
                            src: g(t.remote, {
                                xdm_e: n.protocol + "//" + n.host + n.pathname,
                                xdm_c: t.channel,
                                xdm_p: 4
                            }),
                            name: O + t.channel + "_provider"
                        }), e = m(t), T.Fn.set(t.channel, function(t) {
                            return s = t, o(function() {
                                    i.up.callback(!0)
                                }, 0),
                                function(t) {
                                    i.up.incoming(t, r)
                                }
                        })) : (s = function() {
                            var t = parent;
                            if ("" !== W)
                                for (var i = 0, e = W.split("."); i < e.length; i++) t = t[e[i]];
                            return t.easyXDM
                        }().Fn.get(t.channel)(function(t) {
                            i.up.incoming(t, r)
                        }), o(function() {
                            i.up.callback(!0)
                        }, 0))
                    },
                    init: function() {
                        c(i.onDOMReady, i)
                    }
                }
            }, T.stack.FlashTransport = function(t) {
                function e(t, i) {
                    o(function() {
                        a.up.incoming(t, l)
                    }, 0)
                }

                function s(e) {
                    var n = t.swf + "?host=" + t.isHost,
                        o = "easyXDM_swf_" + Math.floor(1e4 * Math.random());
                    T.Fn.set("flash_loaded" + e.replace(/[\-.]/g, "_"), function() {
                        T.stack.FlashTransport[e].swf = p = v.firstChild;
                        for (var t = T.stack.FlashTransport[e].queue, i = 0; i < t.length; i++) t[i]();
                        t.length = 0
                    }), t.swfContainer ? v = "string" == typeof t.swfContainer ? i.getElementById(t.swfContainer) : t.swfContainer : (f((v = i.createElement("div")).style, L && t.swfNoThrottle ? {
                        height: "20px",
                        width: "20px",
                        position: "fixed",
                        right: 0,
                        top: 0
                    } : {
                        height: "1px",
                        width: "1px",
                        position: "absolute",
                        overflow: "hidden",
                        right: 0,
                        top: 0
                    }), i.body.appendChild(v));
                    var s = "callback=flash_loaded" + r(e.replace(/[\-.]/g, "_")) + "&proto=" + k.location.protocol + "&domain=" + r(k.location.href.match(S)[3]) + "&port=" + r(k.location.href.match(S)[4] || "") + "&ns=" + r(W);
                    v.innerHTML = "<object height='20' width='20' type='application/x-shockwave-flash' id='" + o + "' data='" + n + "'><param name='allowScriptAccess' value='always'></param><param name='wmode' value='transparent'><param name='movie' value='" + n + "'></param><param name='flashvars' value='" + s + "'></param><embed type='application/x-shockwave-flash' FlashVars='" + s + "' allowScriptAccess='always' wmode='transparent' src='" + n + "' height='1' width='1'></embed></object>"
                }
                var a, d, l, p, v;
                return a = {
                    outgoing: function(i, e, n) {
                        p.postMessage(t.channel, i.toString()), n && n()
                    },
                    destroy: function() {
                        try {
                            p.destroyChannel(t.channel)
                        } catch (t) {}
                        p = null, d && (d.parentNode.removeChild(d), d = null)
                    },
                    onDOMReady: function() {
                        l = t.remote, T.Fn.set("flash_" + t.channel + "_init", function() {
                            o(function() {
                                a.up.callback(!0)
                            })
                        }), T.Fn.set("flash_" + t.channel + "_onMessage", e), t.swf = u(t.swf);
                        var i = t.swf.match(S)[3],
                            r = function() {
                                T.stack.FlashTransport[i].init = !0, (p = T.stack.FlashTransport[i].swf).createChannel(t.channel, t.secret, h(t.remote), t.isHost), t.isHost && (L && t.swfNoThrottle && f(t.props, {
                                    position: "fixed",
                                    right: 0,
                                    top: 0,
                                    height: "20px",
                                    width: "20px"
                                }), f(t.props, {
                                    src: g(t.remote, {
                                        xdm_e: h(n.href),
                                        xdm_c: t.channel,
                                        xdm_p: 6,
                                        xdm_s: t.secret
                                    }),
                                    name: O + t.channel + "_provider"
                                }), d = m(t))
                            };
                        T.stack.FlashTransport[i] && T.stack.FlashTransport[i].init ? r() : T.stack.FlashTransport[i] ? T.stack.FlashTransport[i].queue.push(r) : (T.stack.FlashTransport[i] = {
                            queue: [r]
                        }, s(i))
                    },
                    init: function() {
                        c(a.onDOMReady, a)
                    }
                }
            }, T.stack.PostMessageTransport = function(i) {
                function e(t) {
                    if (t.origin) var e = h(t.origin);
                    else if (t.uri) e = h(t.uri);
                    else {
                        if (!t.domain) throw "Unable to retrieve the origin of the event";
                        e = n.protocol + "//" + t.domain
                    }
                    e == d && t.data && t.data.substring && t.data.substring(0, i.channel.length + 1) == i.channel + " " && s.up.incoming(t.data.substring(i.channel.length + 1), e)
                }
                var s, r, a, d;
                return s = {
                    outgoing: function(t, e, n) {
                        a.postMessage(i.channel + " " + t, e || d), n && n()
                    },
                    destroy: function() {
                        N(t, "message", e), r && (a = null, r.parentNode.removeChild(r), r = null)
                    },
                    onDOMReady: function() {
                        if (d = h(i.remote), i.isHost) {
                            var l = function(n) {
                                n.data == i.channel + "-ready" && (a = "postMessage" in r.contentWindow ? r.contentWindow : r.contentWindow.document, N(t, "message", l), R(t, "message", e), o(function() {
                                    s.up.callback(!0)
                                }, 0))
                            };
                            R(t, "message", l), f(i.props, {
                                src: g(i.remote, {
                                    xdm_e: h(n.href),
                                    xdm_c: i.channel,
                                    xdm_p: 1
                                }),
                                name: O + i.channel + "_provider"
                            }), r = m(i)
                        } else R(t, "message", e), (a = "postMessage" in t.parent ? t.parent : t.parent.document).postMessage(i.channel + "-ready", d), o(function() {
                            s.up.callback(!0)
                        }, 0)
                    },
                    init: function() {
                        c(s.onDOMReady, s)
                    }
                }
            }, T.stack.FrameElementTransport = function(e) {
                var s, r, a, d;
                return s = {
                    outgoing: function(t, i, e) {
                        a.call(this, t), e && e()
                    },
                    destroy: function() {
                        r && (r.parentNode.removeChild(r), r = null)
                    },
                    onDOMReady: function() {
                        d = h(e.remote), e.isHost ? (f(e.props, {
                            src: g(e.remote, {
                                xdm_e: h(n.href),
                                xdm_c: e.channel,
                                xdm_p: 5
                            }),
                            name: O + e.channel + "_provider"
                        }), (r = m(e)).fn = function(t) {
                            return delete r.fn, a = t, o(function() {
                                    s.up.callback(!0)
                                }, 0),
                                function(t) {
                                    s.up.incoming(t, d)
                                }
                        }) : (i.referrer && h(i.referrer) != F.xdm_e && (t.top.location = F.xdm_e), a = t.frameElement.fn(function(t) {
                            s.up.incoming(t, d)
                        }), s.up.callback(!0))
                    },
                    init: function() {
                        c(s.onDOMReady, s)
                    }
                }
            }, T.stack.NameTransport = function(t) {
                function i(i) {
                    d.contentWindow.sendMessage(i, t.remoteHelper + (a ? "#_3" : "#_2") + t.channel)
                }

                function e() {
                    a ? 2 != ++p && a || r.up.callback(!0) : (i("ready"), r.up.callback(!0))
                }

                function n(t) {
                    r.up.incoming(t, b)
                }

                function s() {
                    v && o(function() {
                        v(!0)
                    }, 0)
                }
                var r, a, d, l, p, v, b, y;
                return r = {
                    outgoing: function(t, e, n) {
                        v = n, i(t)
                    },
                    destroy: function() {
                        d.parentNode.removeChild(d), d = null, a && (l.parentNode.removeChild(l), l = null)
                    },
                    onDOMReady: function() {
                        a = t.isHost, p = 0, b = h(t.remote), t.local = u(t.local), a ? (T.Fn.set(t.channel, function(i) {
                            a && "ready" === i && (T.Fn.set(t.channel, n), e())
                        }), y = g(t.remote, {
                            xdm_e: t.local,
                            xdm_c: t.channel,
                            xdm_p: 2
                        }), f(t.props, {
                            src: y + "#" + t.channel,
                            name: O + t.channel + "_provider"
                        }), l = m(t)) : (t.remoteHelper = t.remote, T.Fn.set(t.channel, n));
                        var i = function() {
                            var n = d || this;
                            N(n, "load", i), T.Fn.set(t.channel + "_load", s),
                                function t() {
                                    "function" == typeof n.contentWindow.sendMessage ? e() : o(t, 50)
                                }()
                        };
                        d = m({
                            props: {
                                src: t.local + "#_4" + t.channel
                            },
                            onLoad: i
                        })
                    },
                    init: function() {
                        c(r.onDOMReady, r)
                    }
                }
            }, T.stack.HashTransport = function(i) {
                function e() {
                    if (u) {
                        var t = u.location.href,
                            i = "",
                            e = t.indexOf("#"); - 1 != e && (i = t.substring(e)), i && i != d && (d = i, n.up.incoming(d.substring(d.indexOf("_") + 1), v))
                    }
                }
                var n, s, r, a, d, l, u, g, p, v;
                return n = {
                    outgoing: function(t, e) {
                        if (g) {
                            var n = i.remote + "#" + l++ + "_" + t;
                            (s || !p ? g.contentWindow : g).location = n
                        }
                    },
                    destroy: function() {
                        t.clearInterval(r), !s && p || g.parentNode.removeChild(g), g = null
                    },
                    onDOMReady: function() {
                        if (s = i.isHost, a = i.interval, d = "#" + i.channel, l = 0, p = i.useParent, v = h(i.remote), s) {
                            if (f(i.props, {
                                    src: i.remote,
                                    name: O + i.channel + "_provider"
                                }), p) i.onLoad = function() {
                                u = t, r = setInterval(e, a), n.up.callback(!0)
                            };
                            else {
                                var c = 0,
                                    b = i.delay / 50;
                                ! function t() {
                                    if (++c > b) throw Error("Unable to reference listenerwindow");
                                    try {
                                        u = g.contentWindow.frames[O + i.channel + "_consumer"]
                                    } catch (t) {}
                                    u ? (r = setInterval(e, a), n.up.callback(!0)) : o(t, 50)
                                }()
                            }
                            g = m(i)
                        } else u = t, r = setInterval(e, a), p ? (g = parent, n.up.callback(!0)) : (f(i, {
                            props: {
                                src: i.remote + "#" + i.channel + new Date,
                                name: O + i.channel + "_consumer"
                            },
                            onLoad: function() {
                                n.up.callback(!0)
                            }
                        }), g = m(i))
                    },
                    init: function() {
                        c(n.onDOMReady, n)
                    }
                }
            }, T.stack.ReliableBehavior = function(t) {
                var i, e, n = 0,
                    o = 0,
                    s = "";
                return i = {
                    incoming: function(t, r) {
                        var a = t.indexOf("_"),
                            d = t.substring(0, a).split(",");
                        t = t.substring(a + 1), d[0] == n && (s = "", e && e(!0)), 0 < t.length && (i.down.outgoing(d[1] + "," + n + "_" + s, r), o != d[1] && (o = d[1], i.up.incoming(t, r)))
                    },
                    outgoing: function(t, r, a) {
                        s = t, e = a, i.down.outgoing(o + "," + ++n + "_" + t, r)
                    }
                }
            }, T.stack.QueueBehavior = function(t) {
                function i() {
                    if (t.remove && 0 === a.length) ! function(t) {
                        t.up.down = t.down, t.down.up = t.up, t.up = t.down = null
                    }(e);
                    else if (!d && 0 !== a.length && !n) {
                        d = !0;
                        var s = a.shift();
                        e.down.outgoing(s.data, s.origin, function(t) {
                            d = !1, s.callback && o(function() {
                                s.callback(t)
                            }, 0), i()
                        })
                    }
                }
                var e, n, a = [],
                    d = !0,
                    l = "",
                    c = 0,
                    h = !1,
                    u = !1;
                return e = {
                    init: function() {
                        p(t) && (t = {}), t.maxLength && (c = t.maxLength, u = !0), t.lazy ? h = !0 : e.down.init()
                    },
                    callback: function(t) {
                        d = !1;
                        var n = e.up;
                        i(), n.callback(t)
                    },
                    incoming: function(i, n) {
                        if (u) {
                            var o = i.indexOf("_"),
                                r = parseInt(i.substring(0, o), 10);
                            l += i.substring(o + 1), 0 === r && (t.encode && (l = s(l)), e.up.incoming(l, n), l = "")
                        } else e.up.incoming(i, n)
                    },
                    outgoing: function(n, o, s) {
                        t.encode && (n = r(n));
                        var d = [];
                        if (u) {
                            for (; 0 !== n.length;) {
                                var l = n.substring(0, c);
                                n = n.substring(l.length), d.push(l)
                            }
                            for (; l = d.shift();) a.push({
                                data: d.length + "_" + l,
                                origin: o,
                                callback: 0 === d.length ? s : null
                            })
                        } else a.push({
                            data: n,
                            origin: o,
                            callback: s
                        });
                        h ? e.down.init() : i()
                    },
                    destroy: function() {
                        n = !0, e.down.destroy()
                    }
                }
            }, T.stack.VerifyBehavior = function(t) {
                function i() {
                    n = Math.random().toString(16).substring(2), e.down.outgoing(n)
                }
                var e, n, o;
                return e = {
                    incoming: function(s, r) {
                        var a = s.indexOf("_"); - 1 === a ? s === n ? e.up.callback(!0) : o || (o = s, t.initiate || i(), e.down.outgoing(s)) : s.substring(0, a) === o && e.up.incoming(s.substring(a + 1), r)
                    },
                    outgoing: function(t, i, o) {
                        e.down.outgoing(n + "_" + t, i, o)
                    },
                    callback: function(e) {
                        t.initiate && i()
                    }
                }
            }, T.stack.RpcBehavior = function(t, i) {
                function e(t) {
                    t.jsonrpc = "2.0", o.down.outgoing(s.stringify(t))
                }

                function n(t, i) {
                    var n = Array.prototype.slice;
                    return function() {
                        var o = arguments.length,
                            s = {
                                method: i
                            };
                        if (0 < o && "function" == typeof arguments[o - 1]) {
                            if (1 < o && "function" == typeof arguments[o - 2]) {
                                var d = {
                                    success: arguments[o - 2],
                                    error: arguments[o - 1]
                                };
                                s.params = n.call(arguments, 0, o - 2)
                            } else d = {
                                success: arguments[o - 1]
                            }, s.params = n.call(arguments, 0, o - 1);
                            a["" + ++r] = d, s.id = r
                        } else s.params = n.call(arguments, 0);
                        t.namedParams && 1 === s.params.length && (s.params = s.params[0]), e(s)
                    }
                }
                var o, s = i.serializer || U(),
                    r = 0,
                    a = {};
                return o = {
                    incoming: function(t, n) {
                        var o = s.parse(t);
                        if (o.method) i.handle ? i.handle(o, e) : function(t, i, n, o) {
                            if (n) {
                                if (i) var s = function(t) {
                                        s = x, e({
                                            id: i,
                                            result: t
                                        })
                                    },
                                    r = function(t, n) {
                                        r = x;
                                        var o = {
                                            id: i,
                                            error: {
                                                code: -32099,
                                                message: t
                                            }
                                        };
                                        n && (o.error.data = n), e(o)
                                    };
                                else s = r = x;
                                "[object Array]" !== Object.prototype.toString.call(o) && (o = [o]);
                                try {
                                    var a = n.method.apply(n.scope, o.concat([s, r]));
                                    p(a) || s(a)
                                } catch (t) {
                                    r(t.message)
                                }
                            } else i && e({
                                id: i,
                                error: {
                                    code: -32601,
                                    message: "Procedure not found."
                                }
                            })
                        }(o.method, o.id, i.local[o.method], o.params);
                        else {
                            var r = a[o.id];
                            o.error ? r.error && r.error(o.error) : r.success && r.success(o.result), delete a[o.id]
                        }
                    },
                    init: function() {
                        if (i.remote)
                            for (var e in i.remote) i.remote.hasOwnProperty(e) && (t[e] = n(i.remote[e], e));
                        o.down.init()
                    },
                    destroy: function() {
                        for (var e in i.remote) i.remote.hasOwnProperty(e) && t.hasOwnProperty(e) && delete t[e];
                        o.down.destroy()
                    }
                }
            }, k.easyXDM = T
    }(t, i, location, t.setTimeout, decodeURIComponent, encodeURIComponent), void 0 !== t.uLogin && t.uLogin.uLoginHost || (Array.prototype.indexOf || (Array.prototype.indexOf = function(t) {
        try {
            for (var i = 0; i < this.length; i++)
                if (this[i] == t) return i
        } catch (t) {}
        return -1
    }), String.prototype.trim || (String.prototype.trim = function() {
        return this.replace(/^\s+|\s+$/g, "")
    }), void 0 === t.console && (t.console = {
        log: function() {},
        error: function() {},
        info: function() {},
        assert: function() {}
    }), t.uLogin = {
        uLoginHost: function(t) {
            var i;
            for (i in t)
                if (i in t && t[i].src && /^https?:\/\/(.*?)\/js\/ulogin\.js/.test(t[i].src)) {
                    var e = t[i].src.match(/^https?:\/\/([^\/]+)/)[1].replace(/^www\./, "");
                    break
                }
            return "u-login.com" === e ? "u-login.com" : "ulogin.ru"
        }(i.getElementsByTagName("script"))
    }, t.uLogin = {
        version: "3",
        protocol: location.href.match(/^https/i) ? "https" : "http",
        host: encodeURIComponent(location.host),
        uLoginHost: uLogin.uLoginHost,
        supportStorage: !!("localStorage" in window && null !== window.localStorage && "JSON" in window && null !== window.JSON && void 0 !== window.JSON.parse && void 0 !== window.JSON.stringify),
        supportHistory: !(!window.history || !history.pushState),
        ids: [],
        timeouts: {},
        listeners: {},
        lang: (e.language || e.systemLanguage || e.userLanguage || "en").substr(0, 2).toLowerCase(),
        langs: "en ru uk fr de uz".split(" "),
        dialog: !1,
        close: !1,
        lightbox: !1,
        dialogSocket: !1,
        pixel: !1,
        providerCodes: "vkontakte odnoklassniki mailru facebook twitter google yandex livejournal openid flickr lastfm linkedin liveid soundcloud steam webmoney youtube foursquare tumblr googleplus instagram wargaming".split(" "),
        providerNames: "VK Odnoklassniki Mail.ru Facebook Twitter Google Yandex LiveJournal OpenID Flickr Last.FM LinkedIn LiveID SoundCloud Steam WebMoney YouTube foursquare tumblr Google+ Instagram Wargaming.net".split(" "),
        states: ["ready", "open", "receive", "close", "fill"],
        themes: ["classic", "flat"],
        widgetSettings: {},
        findTimer: 0,
        waitGetWidget: {},
        altwayCalled: [],
        rc: !1,
        page: null,
        altway: (o = e.userAgent || e.vendor || t.opera, o = o.toLowerCase(), !!/iPhone|iPad/i.test(o)),
        m: !!/(ip(ad|od|hone)|android)/i.test(e.userAgent || e.vendor || t.opera),
        mobile: function(t) {
            return !/_utl_t=vk/.test(location.href) && !/_utl_t=vk/.test(document.referrer) && (t = t.toLowerCase(), !!/(ip(ad|od|hone)|android)/i.test(t))
        }(e.userAgent || e.vendor || t.opera),
        openFromSocket: !1,
        ppi: null,
        authSocket: !1,
        availableParams: {
            id: 1,
            redirect_uri: 1,
            page: 1,
            callback: 1,
            fields: 1,
            force_fields: 1,
            popup_css: 1,
            optional: 1,
            protocol: 1,
            host: 1,
            lang: 1,
            verify: 1,
            sort: 1,
            othprov: 1,
            providers: 1,
            altway: 1,
            m: 1,
            icons_32: 1,
            icons_16: 1
        },
        cancelClick: !1,
        postMessageIsAvailable: void 0 !== t.postMessage,
        init: function(t) {
            if (i.body) {
                if (this.mobile && (this.altway = !0), this.page = encodeURIComponent(location.href), this.openFromSocket && (this.authSocket = this.initSocket(this.buildUrl("/version/3.0/html/buttons_receiver.html", {
                        four: "",
                        r: parseInt(1e5 * Math.random())
                    }), this.getRC(), {
                        background: "transparent"
                    })), "" == t && (-1 == (t = (t = i.getElementsByTagName("script"))[t.length - 1].src).indexOf("?") && (t += "?"), t = t.substr(t.indexOf("?") + 1)), "" != t) {
                    var e = this.parse(t);
                    if (e.version && (this.version = e.version), e.display) {
                        var o = e.id || "uLogin";
                        if (this.get(o)) {
                            t = !0;
                            for (var s = 0; s < this.ids.length; s++) o == this.ids[s].id && (t = !1);
                            t && this.setProp(e.id || "uLogin", this.ids.length, e)
                        } else n('uLogin.init("' + t + '")', 1e3)
                    }
                }
                this.add(i.body, "touchmove", this.touchMove), uLogin.timeouts.search_all = n(function t() {
                    if (uLogin.findWidgets(), "complete" === i.readyState && (0 === uLogin.findTimer && (uLogin.findTimer = +new Date), 1e4 < new Date - uLogin.findTimer)) return !1;
                    uLogin.timeouts.all = n(t, 50)
                }, 50), this.findWidgets(), uLogin.timeouts.search_ulogin = n(function t() {
                    uLogin.checkAsyncWidgets(), uLogin.timeouts.search_ulogin = n(t, 50)
                }, 50), this.checkAsyncWidgets(), uLogin.timeouts.check_widgets = n(function t() {
                    uLogin.checkCurrentWidgets(), uLogin.timeouts.check_widgets = n(t, 300)
                }, 30), this.checkCurrentWidgets(), this.sendPixel(), uLogin.postMessageIsAvailable && (window.addEventListener ? window.addEventListener("message", uLogin.onMessage) : window.attachEvent("onmessage", uLogin.onMessage))
            } else n(function() {
                uLogin.init()
            }, 20);
            this.callbackReceived()
        },
        onMessage: function(i) {
            i.origin == "https://" + uLogin.uLoginHost && i.data && i.data.mine && i.data.func && ("object" == typeof i.data.func && (i.data.func = i.data.func[0]), "to_window" === i.data.func ? (src = uLogin.buildUrl(i.data.args[2], {
                fields: i.data.args[0],
                filled: i.data.args[1],
                set: encodeURIComponent("{window:1}")
            }), console.log(src), uLogin.loadWindow(src)) : t[i.data.func] && t[i.data.func].apply(uLogin, i.data.args || []))
        },
        get: function(t) {
            return i.getElementById(t)
        },
        exists: function(t) {
            return void 0 !== t
        },
        add: function(t, i, e) {
            t.addEventListener ? t.addEventListener(i, function(n) {
                "click" === i && uLogin.cancelClick || e(t, n)
            }, !1) : t.attachEvent ? t.attachEvent("on" + i, function(n) {
                "click" === i && uLogin.cancelClick || e(t, n)
            }) : t["on" + i] = function(n) {
                "click" === i && uLogin.cancelClick || e(t, n)
            }, "click" === i && (this.add(t, "touchstart", this.touchStart), this.add(t, "touchend", function(t, i) {
                return function(e, n) {
                    uLogin.cancelClick || (uLogin.cancelClick = !0, i.call(this, t, n))
                }
            }(t, e)))
        },
        touchStart: function() {
            uLogin.cancelClick = !1
        },
        touchMove: function() {
            uLogin.cancelClick = !0
        },
        is_encoded: function(t) {
            return decodeURIComponent(t) != t
        },
        genID: function() {
            for (var t = new Date, i = t.getTime() + Math.floor(1e5 * Math.random()); this.get("ul_" + i);) i = t.getTime() + Math.floor(1e5 * Math.random());
            return "ul_" + i
        },
        show: function(t) {
            this.exists(t) && (t.style.display = "block")
        },
        hide: function(t) {
            t && this.exists(t) && (t.style.display = "none")
        },
        parse: function(t) {
            var i = {};
            if (!t) return i;
            if ("object" == typeof t) return t;
            var e = t.split("&");
            for (e = 1 < e.length ? e : t.split(";"), t = 0; t < e.length; t++) {
                var n = e[t].split("=");
                n[0] && (n[0] = n[0].trim()), n[1] && (n[1] = n[1].trim()), i[n[0]] = n[1]
            }
            return i
        },
        scrollTop: function() {
            return t.pageYOffset || i.documentElement.scrollTop || i.body.scrollTop
        },
        scrollLeft: function() {
            return t.pageXOffset || i.documentElement.scrollLeft || i.body.scrollLeft
        },
        dialogHeight: function() {
            return 358
        },
        dialogWidth: function() {
            return 564
        },
        clientWidth: function() {
            var e = 0;
            return "[object Opera]" == Object.prototype.toString.call(t.opera) && 9.5 > t.parseFloat(t.opera.version()) ? e = i.body.clientWidth : t.innerWidth && (e = t.innerWidth), this.isIE() && (e = i.documentElement.clientWidth), e
        },
        clientHeight: function() {
            var e = 0;
            return "[object Opera]" == Object.prototype.toString.call(t.opera) && 9.5 > t.parseFloat(t.opera.version()) ? e = i.body.clientHeight : t.innerHeight && (e = t.innerHeight), this.isIE() && (e = i.documentElement.clientHeight), e
        },
        isIE: function() {
            if (/MSIE (\d+\.\d+);/.test(e.userAgent)) {
                var t = Number(RegExp.$1);
                if (9 > t) return t
            }
            return !1
        },
        getPPI: function() {
            if (null === this.ppi) try {
                var t = window.devicePixelRatio || 1,
                    i = document.getElementsByTagName("body")[0],
                    e = document.createElement("div");
                e.style = "height: 1in; left: -100%; position: absolute; top: -100%; width: 1in;", i.appendChild(e);
                var n = e.offsetWidth * t;
                i.removeChild(e), this.ppi = n
            } catch (t) {
                this.ppi = 96
            }
            return this.ppi
        },
        inArray: function(t, i) {
            if (!t || !i) return !1;
            for (var e = 0, n = i.length; e < n; e++)
                if (t == i[e]) return e;
            return -1
        },
        findWidgets: function() {
            for (var t = 0, e = [], n = [], o = i.getElementsByTagName("div"), s = i.getElementsByTagName("a"); s[t];) s[t] && (e[t] = s[t]), t++;
            for (t = 0; o[t];) o[t] && (n[t] = o[t]), t++;
            for (t = 0; n[t] || e[t];) n[t] && this.addWidget(n[t]), e[t] && this.addWidget(e[t]), t++
        },
        addWidget: function(i, e) {
            var n = i.id,
                o = i.getAttribute("data-uloginid"),
                s = {},
                r = !1;
            void 0 !== t.uLoginParams && (t.uLoginParams[n] ? s = t.uLoginParams[n] : t.uLoginParams[o] ? s = t.uLoginParams[o] : 0 < this.arrayIntersectKey(t.uLoginParams, this.availableParams).length && (s = t.uLoginParams, r = !0)), e && (s = this.extend(s, e));
            var a = i.getAttribute("data-ulogin") || i.getAttribute("x-ulogin-params");
            r = null !== a || !r && 0 < this.arrayIntersectKey(s, this.availableParams).length, e = this.extend(this.parse(a), s), !o && !r || n || (n = this.genID(), i.setAttribute("id", n)), o ? this.getWidget(o, n) : r && this.setProp(n, this.ids.length, e)
        },
        inited: function(t) {
            for (var i = 0; i < this.ids.length; i++)
                if (t == this.ids[i].id) return !0;
            return !1
        },
        initWidget: function(t) {
            if (t) {
                var i = this.get(t);
                if (i && (i = i.getAttribute("data-ulogin") || i.getAttribute("x-ulogin-params")) && !this.inited(t)) {
                    i = this.parse(i);
                    var e = this.getWidgetNumber(t);
                    isNaN(e) ? e = this.ids.length : this.ids[e] = {}, this.setProp(t, e, i)
                }
            }
        },
        setProp: function(t, i, e) {
            if (this.waitGetWidget[t] || this.inited(t)) return !1;
            switch (this.ids[i] = {
                id: t,
                dropTimer: !1,
                initCheck: !1,
                type: e.display || "",
                providers: e.providers || "",
                hidden: e.hidden || "",
                redirect_uri: e.redirect_uri || "",
                page: this.page,
                callback: e.callback || "",
                fields: e.fields || "first_name,last_name,email",
                force_fields: e.force_fields || "",
                popup_css: e.popup_css || "",
                optional: e.optional || "",
                color: e.color || "fff",
                opacity: e.opacity || "75",
                verify: e.verify || "",
                m: void 0 !== e.m ? e.m : this.m,
                lang: e.lang || this.lang,
                altway: void 0 !== e.altway ? parseInt(e.altway) : this.altway,
                sort: "default" === e.sort ? "default" : "relevant",
                state: "",
                hidden_button: e.hidden_button || "inset",
                dropdown_container: e.dropdown_container || "body",
                icons_32: e.icons_32 || "",
                icons_16: e.icons_16 || "",
                theme: e.theme || "classic",
                client: e.client || "",
                event: e.event || "click"
            }, -1 == this.inArray(this.ids[i].theme, this.themes) && (this.ids[i].theme = this.themes[0]), this.ids[i].providers || this.ids[i].other || (this.ids[i].hidden = "other"), "small" !== this.ids[i].type && "panel" !== this.ids[i].type || this.sendStats({
                type: this.ids[i].type
            }), "window" == this.ids[i].type && !this.ids[i].providers && this.ids[i].hidden && (this.ids[i].providers = this.providerCodes.join(",")), this.ids[i].mobile = 0 == e.mobilebuttons ? 0 : this.mobile, this.ids[i].altway && !this.ids[i].redirect_uri && (this.ids[i].redirect_uri = location.href), this.ids[i].callback && !this.ids[i].altway && (this.ids[i].redirect_uri = ""), this.ids[i].redirect_uri = this.clearRedirectUri(this.ids[i].redirect_uri), -1 == this.inArray(this.ids[i].lang, this.langs) && (this.ids[i].lang = this.lang), this.ids[i].icons_32 = this.fixSiteLink(this.ids[i].icons_32), this.ids[i].icons_16 = this.fixSiteLink(this.ids[i].icons_16), e.display) {
                case "small":
                case "panel":
                    this.ids[i].listener_id = !1, this.initPanel(i);
                    break;
                case "window":
                    this.initWindow(i);
                    break;
                case "buttons":
                    this.initButtons(i);
                    break;
                default:
                    this.ids.splice(i, i)
            }
            this.get(t).setAttribute("data-ulogin-inited", (+new Date).toString())
        },
        fixSiteLink: function(t) {
            return t && (/^https?:\/\/(.*?)/.test(t) || (/^\//.test(t) || (t = "/" + t), t = location.origin + t), new RegExp("^" + location.origin).test(t) || (t = "", console.error("uLogin ERROR: resource link is invalid, not match with location.origin")), t && (t = this.is_encoded(t) ? t.replace(/\//g, "%2F").replace(/\?/g, "%3F") : encodeURIComponent(t))), t
        },
        clearRedirectUri: function(t) {
            return t ? (t = t.replace(/ulogin_callback=([^&?]*?)#/, "#").replace(/ulogin_callback=(.*?)(&|$)/, "").replace(/ulogin_token=([^&?]*?)#/, "#").replace(/ulogin_token=(.*?)(&|$)/, "").replace(/(\?|&)#/, "#").replace(/(\?|&)$/, ""), this.is_encoded(t) ? t.replace(/\//g, "%2F").replace(/\?/g, "%3F") : encodeURIComponent(t)) : t
        },
        initPanel: function(t) {
            var e, n = this.get(this.ids[t].id),
                o = "small" == this.ids[t].type ? 1 : 0,
                s = o ? 21 : 42,
                r = o ? 16 : 32,
                a = 0,
                d = o ? 5 : 10,
                l = o ? "16px" : "32px",
                c = "",
                h = "";
            if (this.ids[t].icons_16 && o ? c = decodeURIComponent(this.ids[t].icons_16) : this.ids[t].icons_32 && !o ? c = decodeURIComponent(this.ids[t].icons_32) : (h = 120 < this.getPPI() ? o ? 32 : 64 : o ? 16 : 32, c = "providers-{size}-{theme}.png?version=img.3.0.1".replace("{size}", h).replace("{theme}", this.ids[t].theme), c = this.buildUrl("version/3.0/img/" + c), h = "smiles-{size}.png?version=img.3.0.1".replace("{size}", h).replace("{theme}", this.ids[t].theme), h = this.buildUrl("img/" + h), this.ids[t].hovered_sprite = h), c = "url(" + c + ") " + (o ? "0 -1px" : "0 -2px") + " no-repeat", n.innerHTML = "", "other" === this.ids[t].hidden) {
                var u = this.providerCodes.slice(0);
                if (this.ids[t].providers) {
                    h = this.ids[t].providers.split(",");
                    for (var g = 0; g < h.length; g++) {
                        var p = this.inArray(h[g], u); - 1 !== p && u.splice(p, 1)
                    }
                }
                this.ids[t].hidden = u.toString()
            }
            if (this.ids[t].providers)
                for (e in h = "relevant" === this.ids[t].sort ? this.relProviders(this.ids[t].providers, this.ids[t].hidden, 1) : this.ids[t].providers.split(","), a += s * ("inset" === this.ids[t].hidden_button && 0 < this.ids[t].hidden.length ? h.length + 1 : h.length), s = i.createElement("div"), this.ids[t].buttonsContainer = s, this.ids[t].buttonsContainer.className = "ulogin-buttons-container", this.resetStyle(s, {
                        width: a,
                        maxWidth: "100%",
                        minHeight: r,
                        verticalAlign: "top",
                        display: "inline-block",
                        lineHeight: 0
                    }), n.appendChild(s), h) a = h[e], -1 < (u = this.inArray(a, this.providerCodes)) && ((s = i.createElement("div")).className = "ulogin-button-" + a, s.setAttribute("data-uloginbutton", a), s.setAttribute("role", "button"), s.setAttribute("title", this.providerNames[u]), this.resetStyle(s, {
                    float: "left",
                    width: r,
                    height: r,
                    margin: "0 " + d + "px " + d + "px 0",
                    background: c,
                    cursor: "pointer",
                    backgroundPosition: this.getIconPosition(o, u),
                    backgroundSize: l
                }), this.ids[t].buttonsContainer.appendChild(s));
            this.ids[t].hidden && (n.style.position = "relative", "relevant" === this.ids[t].sort && (this.ids[t].hidden = this.relProviders(this.ids[t].providers, this.ids[t].hidden, 2).join(",")), this.ids[t].drop = i.createElement("div"), this.ids[t].drop.className = "ulogin-dropdown-button", this.resetStyle(this.ids[t].drop, {
                width: r,
                height: r,
                margin: "0 " + d + "px " + d + "px 0",
                cursor: "pointer",
                background: c,
                verticalAlign: "baseline",
                display: "inline-block",
                float: "none",
                backgroundSize: l
            }), this.ids[t].mobile || (this.add(this.ids[t].drop, "mouseover", function(i) {
                uLogin.ids[t].showed = !1, uLogin.dropdownDelayed(t, o ? 1 : 2), uLogin.setOpacity(i, uLogin.ids[t].opacity)
            }), this.add(this.ids[t].drop, "mouseout", function(i) {
                uLogin.ids[t].showed = !0, uLogin.dropdownDelayed(t, 0), uLogin.setOpacity(i)
            }), this.add(this.ids[t].drop, "click", function() {
                uLogin.dropdown(t, o ? 1 : 2)
            })), "inset" === this.ids[t].hidden_button && this.ids[t].buttonsContainer ? this.ids[t].buttonsContainer.appendChild(this.ids[t].drop) : n.appendChild(this.ids[t].drop), this.ids[t].mobile || this.initDrop(t)), this.ids[t].buttonsContainer && 0 < this.ids[t].buttonsContainer.clientHeight && (this.ids[t].buttonsContainer.style.height = this.ids[t].buttonsContainer.clientHeight - d + "px"), window.bc = this.ids[t].buttonsContainer, this.initButtons(t)
        },
        initWindow: function(t) {
            var e = this.get(this.ids[t].id),
                n = e.getElementsByTagName("*");
            n.length ? e = n[0] : e.innerHTML ? ((n = document.createElement("span")).innerHTML = e.innerHTML, e.innerHTML = "", e = e.appendChild(n)) : ((n = i.createElement("img")).setAttribute("src", this.buildUrl("img/button.png?version=img.3.0.1")), n.setAttribute("style", "cursor:pointer; width:187px; height:30px"), n.setAttribute("alt", "МультиВход"), e = e.appendChild(n)), e.setAttribute("data-uloginbutton", "window"), e.setAttribute("data-ulogin-default", "true"), this.ids[t].opacity = 75, this.initButtons(t)
        },
        sendPixel: function() {
            if (this.getRC(), this.pixel) {
                var t = this;
                n(function() {
                    if (t.pixel) {
                        var e = i.createElement("iframe"),
                            o = t.getRC();
                        e.src = t.pixel.replace("[rand]", parseInt(1e5 * Math.random())).replace("[u]", encodeURIComponent(location.href)).replace("[r]", encodeURIComponent(i.referrer || "")), e.width = e.height = 1, e.style.display = "none", o.appendChild(e), n(function() {
                            o.removeChild(e)
                        }, 3e3), t.pixel = !1
                    }
                }, 0)
            }
        },
        sendStats: function(t) {
            var i = {
                r: parseInt(1e5 * Math.random())
            };
            t.type && (i.type = t.type), t = this.buildUrl("stats.html", i), this.initSocket(t, this.getRC())
        },
        mergeAccounts: function(t, i) {
            if (!t) return console.error('uLogin ERROR (mergeAccounts): invalid token "' + t + '"'), !1;
            var e = {
                token: t
            };
            i ? (void 0 !== i.join && (i = i.join(",")), e.identities = encodeURIComponent(i), e = this.buildUrl("merge_accounts.php", e)) : e = this.buildUrl("require_verify.php", e), this.loadWindow(e)
        },
        getRC: function() {
            var t = document.getElementById("ulogin_receiver_container");
            return t || ((t = i.createElement("div")).setAttribute("id", "ulogin_receiver_container"), this.resetStyle(t, {
                width: 0,
                height: 0,
                display: "none"
            }), i.getElementsByTagName("body")[0].appendChild(t)), t
        },
        clearTimeouts: function() {
            for (var t in this.timeouts) clearTimeout(this.timeouts[t])
        },
        callbackTryCall: function(i, e) {
            this.altwayCalled.push(i), t[i] ? setTimeout(function() {
                t[i].call(t, e)
            }, 10) : setTimeout(function() {
                uLogin.callbackTryCall(i, e)
            }, 100)
        },
        callbackReceived: function() {
            var t = location.search.replace("?", "");
            if ((t = this.parse(t)) && t.ulogin_callback && t.ulogin_token && -1 === this.inArray(t.ulogin_callback, this.altwayCalled) && (this.callbackTryCall(t.ulogin_callback, t.ulogin_token), this.supportHistory)) {
                var i = document.getElementsByTagName("title");
                i = (i = i ? i[0] : "") ? i.innerHTML : "", delete t.ulogin_callback, delete t.ulogin_token, t = this.buildUrl("", t, !0);
                var e = location.origin + location.pathname + t + location.hash;
                n(function() {
                    window.history.pushState({}, i, e)
                }, 1e3)
            }
        },
        newDialogSocket: function(t) {
            this.dialogSocket && this.dialogSocket.destroy(), this.dialogSocket = t
        },
        initSocket: function(i, e, n, o) {
            o || (o = 0);
            var s = new easyXDM.Socket({
                remote: i,
                swf: this.isIE() ? this.buildUrl("js/easyxdm.swf") : "",
                props: {
                    style: this.extend({
                        margin: 0,
                        padding: 0,
                        background: "#fff",
                        border: 0,
                        position: "absolute",
                        left: 0,
                        top: 0,
                        overflow: "hidden",
                        width: "100%",
                        height: "100%"
                    }, n),
                    frameBorder: "0"
                },
                container: e,
                onMessage: function(i) {
                    var e;
                    if (/weights:/.test(i) || console.info("[uLogin] ulogin.js received message: " + i), e = i.match(/(.*?)\((.*?)\)/)) {
                        var n = e[1];
                        i = e[2]
                    }
                    if (e = i.match(/^(.*?):(.*?)$/)) var r = e[1],
                        a = e[2];
                    /^https?:\/\//.test(i) ? location.href = i : /^\/auth.php\?/.test(i) ? (i = "https://" + uLogin.uLoginHost + i, uLogin.ids[o].altway ? location.href = i : uLogin.openWithReceiver(i, o)) : -1 < uLogin.inArray(i, uLogin.states) ? uLogin._changeState(o, i) : r && -1 < uLogin.inArray(r, uLogin.states) ? uLogin._changeState(o, r, "string" == typeof a ? a.split(",") : []) : "closeme" == i ? (uLogin.hideAll(), s.destroy()) : /to_window:/.test(i) ? (n = uLogin.buildUrl(i.replace(/to_window:\/?/, "", ""), {
                        set: encodeURIComponent("{window:1}")
                    }), uLogin.loadWindow(n), /to_window:\/fill\.php/.test(i) && uLogin._changeState(o, "fill")) : /weights:/.test(i) ? uLogin.setWeights(i.replace(/weights:\/?/, "", "")) : n ? void 0 !== t[n] && (t[n].apply(t, i.split(",")), s.destroy(), uLogin.dialog && uLogin.hideAll()) : uLogin.ids[o] && void 0 !== t[uLogin.ids[o].callback] && (uLogin._changeState(o, "receive"), t[uLogin.ids[o].callback](i), uLogin.dialog && uLogin.hideAll())
                }
            });
            return s
        },
        getWidgetNumber: function(t) {
            for (var i = 0; i < this.ids.length; i++)
                if (t == this.ids[i].id) return i;
            return NaN
        },
        onMoveWindow: function() {
            this.moveWindow()
        },
        loadWindow: function(e, n) {
            null === n && (n = !1);
            var o = this.ids[n] ? this.ids[n].opacity : 75;
            try {
                i.body.removeChild(this.lightbox)
            } catch (t) {}
            try {
                i.body.removeChild(this.dialog)
            } catch (t) {}
            var s = i.createElement("div");
            this.resetStyle(s, {
                position: "fixed",
                zIndex: 9997,
                width: "100%",
                height: "100%",
                background: "#" + (this.ids[n] ? this.ids[n].color : "fff"),
                display: "none"
            }), this.setOpacity(s, o), this.lightbox = s, (s = i.createElement("div")).id = this.genID(), s.className = "ulogin-popup", this.resetStyle(s, {
                position: "absolute",
                zIndex: 9998,
                left: Math.floor(this.scrollLeft() + (this.clientWidth() - this.dialogWidth()) / 2),
                top: Math.floor(this.scrollTop() + (this.clientHeight() - this.dialogHeight()) / 2),
                width: this.dialogWidth(),
                height: this.dialogHeight(),
                overflow: "visible",
                display: "none",
                border: this.ids[n] && "flat" === this.ids[n].theme ? "5px solid #666" : "10px solid #666",
                borderRadius: this.ids[n] && "flat" === this.ids[n].theme ? 0 : "8px",
                boxShadow: "0 2px 3px 0 rgba(0,0,0,.2),0 3px 2px -2px rgba(0,0,0,.22),0 1px 6px 0 rgba(0,0,0,.12)"
            }), this.dialog = s, (s = i.createElement("div")).className = "ulogin-popup-close", this.resetStyle(s, {
                position: "absolute",
                width: 30,
                height: 30,
                zIndex: 9999,
                background: "url(" + this.buildUrl("img/x.png") + ")",
                cursor: "pointer",
                display: "none",
                left: "initial",
                top: "-15px",
                right: "-15px"
            }), this.close = s, i.body.appendChild(this.lightbox), i.body.appendChild(this.dialog), this.dialog.appendChild(this.close), this.add(this.lightbox, "click", function() {
                uLogin.hideAll()
            }), this.add(this.close, "click", function() {
                uLogin.hideAll()
            }), this.add(this.close, "mouseover", function(t) {
                t.style.background = "url(" + uLogin.buildUrl("img/x_.png") + ")"
            }), this.add(this.close, "mouseout", function(t) {
                t.style.background = "url(" + uLogin.buildUrl("img/x.png") + ")"
            }), this.add(t, "scroll", function() {
                uLogin.onMoveWindow()
            }), this.add(t, "resize", function() {
                uLogin.onMoveWindow()
            }), this.newDialogSocket(this.initSocket(e, this.dialog.getAttribute("id"), {}, n)), uLogin.show(uLogin.close), uLogin.show(uLogin.lightbox), uLogin.show(uLogin.dialog), uLogin.onMoveWindow()
        },
        hideAll: function() {
            this.hide(this.lightbox), this.hide(this.dialog), this.hide(this.close);
            for (var t = 0; t < this.ids.length; t++) this.ids[t].showed = !1, this.hide(this.ids[t].hiddenW), this.hide(this.ids[t].hiddenA)
        },
        moveWindow: function() {
            if (!this.dialog || !this.dialog.firstChild) return !1;
            var t = this.dialogWidth(),
                i = this.dialogHeight();
            t = (Math.floor(this.scrollLeft() + (this.clientWidth() - t) / 2) - Number(this.dialog.style.left.slice(0, -2))) / 10, i = (Math.floor(this.scrollTop() + (this.clientHeight() - i) / 2) - Number(this.dialog.style.top.slice(0, -2))) / 10;
            for (var e = 0; 10 > e; e++) this.dialog.style.left = t + Number(this.dialog.style.left.slice(0, -2)) + "px", this.dialog.style.top = i + Number(this.dialog.style.top.slice(0, -2)) + "px"
        },
        resetStyle: function(t, i) {
            !i && (i = {});
            var e, n = this.extend({
                    margin: 0,
                    padding: 0,
                    outline: "none",
                    border: "none",
                    borderRadius: 0,
                    cursor: "default",
                    float: "none",
                    position: "relative",
                    display: "inherit",
                    width: "auto",
                    height: "auto",
                    left: 0,
                    top: 0,
                    boxSizing: "content-box"
                }, i),
                o = ["width", "height", "left", "top"],
                s = ["float"];
            for (e in n) {
                -1 < this.inArray(e, o) && "number" == typeof n[e] && (n[e] += "px");
                try {
                    -1 < this.inArray(e, s) && t.style.setProperty(e, n[e])
                } catch (t) {}
                try {
                    t.style[e] = n[e]
                } catch (t) {}
            }
        },
        getIconPosition: function(t, i) {
            return t ? "0 -" + (18 + 17 * i) + "px" : "0 -" + (36 + 34 * i) + "px"
        },
        setOpacity: function(t, i) {
            t.style.filter = i ? "alpha(opacity=" + i + ") progid:DXImageTransform.Microsoft.AlphaImageLoader(src=transparent.png, sizingMethod='crop')" : "", t.style.opacity = i ? parseFloat(i) / 100 : ""
        },
        initDrop: function(t) {
            if (!this.ids[t].mobile && "" != this.ids[t].hidden) {
                var e = this.get(this.ids[t].id),
                    n = this.genID(),
                    o = 310 < 23 * this.ids[t].hidden.split(",").length - 2 ? 310 : 23 * this.ids[t].hidden.split(",").length - 2,
                    s = i.createElement("div");
                s.className = "ulogin-dropdown", s.id = n, this.resetStyle(s, {
                    position: "absolute",
                    zIndex: 9999,
                    width: 128,
                    height: o,
                    border: "flat" === this.ids[t].theme ? "3px solid #666" : "5px solid #666",
                    borderRadius: "flat" === this.ids[t].theme ? 0 : "4px",
                    boxShadow: "0 2px 2px 0 rgba(0,0,0,.14),0 3px 1px -2px rgba(0,0,0,.2),0 1px 5px 0 rgba(0,0,0,.12)",
                    display: "none"
                }), this.ids[t].hiddenW = s, "body" === this.ids[t].dropdown_container ? i.body.appendChild(this.ids[t].hiddenW) : e.appendChild(this.ids[t].hiddenW), s = this.buildUrl("/version/3.0/html/drop.html", {
                    id: t,
                    redirect_uri: this.ids[t].redirect_uri,
                    callback: this.ids[t].callback,
                    providers: this.ids[t].hidden,
                    fields: this.ids[t].fields,
                    force_fields: this.ids[t].force_fields,
                    popup_css: this.ids[t].popup_css,
                    optional: this.ids[t].optional,
                    othprov: this.ids[t].providers,
                    protocol: this.protocol,
                    host: this.host,
                    lang: this.ids[t].lang,
                    verify: this.ids[t].verify,
                    sort: this.ids[t].sort,
                    altway: this.ids[t].altway ? 1 : null,
                    m: this.ids[t].m ? 1 : 0,
                    icons_32: this.ids[t].icons_32,
                    icons_16: this.ids[t].icons_16,
                    theme: this.ids[t].theme,
                    client: this.ids[t].client,
                    page: this.page,
                    version: this.version
                }), this.initSocket(s, n, {
                    position: "relative",
                    width: "128px",
                    height: o + "px"
                }, t), s = i.createElement("div"), this.resetStyle(s, {
                    position: "absolute",
                    background: "#000",
                    left: "initial",
                    right: "flat" === this.ids[t].theme ? "-3px" : "-5px",
                    top: "100%",
                    width: 41,
                    height: 13,
                    border: "flat" === this.ids[t].theme ? "3px solid #666" : "5px solid #666",
                    textAlign: "center"
                }), (o = i.createElement("a")).href = this.buildUrl(""), o.target = "_blank", this.resetStyle(o, {
                    width: 41,
                    height: 13,
                    background: "url(" + this.buildUrl("img/text.png") + ") no-repeat"
                }), s.appendChild(o), this.ids[t].hiddenW.appendChild(s), s = i.createElement("div"), this.resetStyle(s, {
                    width: 0,
                    height: 0,
                    position: "absolute",
                    zIndex: 9999,
                    display: "none",
                    border: "5px solid transparent",
                    borderBottomColor: "#666"
                }), this.ids[t].hiddenA = s, e.appendChild(this.ids[t].hiddenA), this.ids[t].showed = !1, this.add(i.body, "click", function(t, i) {
                    i.target || (i.target = i.srcElement);
                    for (var e = 0; e < uLogin.ids.length; e++) i.target != uLogin.ids[e].drop && (uLogin.hide(uLogin.ids[e].hiddenW), uLogin.hide(uLogin.ids[e].hiddenA))
                }), this.ids[t].hiddenW && this.ids[t].hiddenA && (this.add(this.ids[t].hiddenW, "mouseout", function() {
                    uLogin.dropdownDelayed(t, 0)
                }), this.add(this.ids[t].hiddenA, "mouseout", function() {
                    uLogin.dropdownDelayed(t, 0)
                }), this.add(this.ids[t].hiddenW, "mouseover", function() {
                    uLogin.clearDropTimer(t)
                }), this.add(this.ids[t].hiddenA, "mouseover", function() {
                    uLogin.clearDropTimer(t)
                }))
            }
        },
        showDrop: function(t, i) {
            if (this.ids[t].hiddenW || this.ids[t].hiddenA)
                if (this.ids[t].showed || 0 == i) this.hide(this.ids[t].hiddenW), this.hide(this.ids[t].hiddenA), this.ids[t].showed = !1;
                else {
                    this.show(this.ids[t].hiddenA), this.show(this.ids[t].hiddenW), this.ids[t].showed = !0;
                    var e = this.ids[t].drop;
                    if ("body" === this.ids[t].dropdown_container) {
                        var n = this.getOffset(e),
                            o = n.left;
                        n = n.top, this.ids[t].hiddenW.style.left = o - (1 == i ? 100 : 106) + "px", this.ids[t].hiddenW.style.top = n + (1 == i ? 21 : 37) + "px", this.ids[t].hiddenA.style.left = o + (1 == i ? 4 : 12) + "px", this.ids[t].hiddenA.style.top = n + (1 == i ? 17 : 33) + "px"
                    }
                    o = e.offsetLeft, n = e.offsetTop, o -= e.scrollLeft, n -= e.scrollTop, "body" !== this.ids[t].dropdown_container && (this.ids[t].hiddenW.style.left = o - (1 == i ? 100 : 106) + "px", this.ids[t].hiddenW.style.top = n + (1 == i ? 21 : 37) + "px"), this.ids[t].hiddenA.style.left = o + (1 == i ? 4 : 12) + "px", this.ids[t].hiddenA.style.top = n + (1 == i ? 12 : 28) + "px"
                }
        },
        clearDropTimer: function(i) {
            this.ids[i].dropTimer && t.clearTimeout(this.ids[i].dropTimer)
        },
        dropdown: function(t, i) {
            this.ids[t].mobile || (this.clearDropTimer(t), this.showDrop(t, i))
        },
        dropdownDelayed: function(t, i) {
            this.clearDropTimer(t), this.ids[t].dropTimer = n(function() {
                uLogin.showDrop(t, i)
            }, 600)
        },
        initButtons: function(i) {
            var e = this.get(this.ids[i].id);
            this.ids[i].mobile && this.add(this.get(this.ids[i].id), "click", function(e, n) {
                n.preventDefault ? n.preventDefault() : n.returnValue = !1;
                var o = uLogin.buildUrl("version/3.0/html/mobile.html", {
                    id: uLogin.ids[i].id,
                    redirect_uri: uLogin.ids[i].redirect_uri,
                    callback: uLogin.ids[i].callback,
                    fields: uLogin.ids[i].fields,
                    force_fields: uLogin.ids[i].force_fields,
                    popup_css: uLogin.ids[i].popup_css,
                    optional: uLogin.ids[i].optional,
                    protocol: uLogin.ids[i].protocol,
                    host: uLogin.host,
                    lang: uLogin.ids[i].lang,
                    verify: uLogin.ids[i].verify,
                    providers: uLogin.ids[i].providers,
                    hidden: uLogin.ids[i].hidden,
                    icons_32: uLogin.ids[i].icons_32,
                    altway: uLogin.ids[i].altway ? 1 : null,
                    page: uLogin.page,
                    m: uLogin.ids[i].m ? 1 : 0,
                    icons_16: uLogin.ids[i].icons_16,
                    theme: uLogin.ids[i].theme,
                    client: uLogin.ids[i].client,
                    version: uLogin.version
                });
                return uLogin.ids[i].altway ? t.top ? t.top.location.href = o : location.href = o : uLogin.openWithReceiver(o, i), !1
            }), "window" === this.ids[i].type ? this._proceedChildren(e, this._(this._initButton), i) : (this.ids[i].providers = "", this._proceedChildren(e, this._(this._initButton), i), this.ids[i].providers = this.ids[i].providers.slice(0, this.ids[i].providers.length - 1)), this._changeState(i, this.states[0])
        },
        _: function(t) {
            return function() {
                t.apply(uLogin, arguments)
            }
        },
        _proceedChildren: function(t, i, e) {
            var n, o;
            for (t = t.childNodes, o = 0; o < t.length; o++) {
                var s = t[o];
                s.getAttribute && (i(s, e), (n = s.getAttribute("data-uloginbutton") || s.getAttribute("x-ulogin-button")) && -1 < this.inArray(n, this.providerCodes) && !new RegExp(n + "(,|$)", "i").test(this.ids[e].providers) && (this.ids[e].providers += n + ",")), this._proceedChildren(s, i, e)
            }
        },
        _initButton: function(t, i) {
            var e = t.getAttribute("data-uloginbutton") || t.getAttribute("x-ulogin-button");
            if (e)
                if (-1 < this.inArray(e, this.providerCodes)) this.add(t, "mouseover", function(t) {
                    if (/disabled/.test(t.className)) return !1;
                    if (uLogin.setOpacity(t, parseFloat(uLogin.ids[i].opacity)), +new Date < +new Date("2017/04/02 03:00:00") && uLogin.ids[i].hovered_sprite && !t.getAttribute("data-original-background")) {
                        var e = t.offsetHeight * uLogin.randFromTo(0, 24),
                            n = "ru" === uLogin.ids[i].lang ? "1 апреля - день смеха! Улыбайтесь )" : "April Fools' Day is here!";
                        t.setAttribute("data-original-background", t.style.background), t.style.background = "url(" + uLogin.ids[i].hovered_sprite + ") 0px -" + e + "px no-repeat", t.setAttribute("data-original-title", t.getAttribute("title")), t.setAttribute("title", n)
                    }
                }), this.add(t, "mouseout", function(t) {
                    if (/disabled/.test(t.className)) return !1;
                    uLogin.setOpacity(t), t.getAttribute("data-original-background") && (t.style.background = t.getAttribute("data-original-background"), t.removeAttribute("data-original-background")), t.getAttribute("data-original-title") && (t.setAttribute("title", t.getAttribute("data-original-title")), t.removeAttribute("data-original-title"))
                }), this.ids[i].mobile || this.add(t, "click", function(t) {
                    if (/disabled/.test(t.className)) return !1;
                    var e = t.getAttribute("data-uloginbutton") || t.getAttribute("x-ulogin-button");
                    if (t.getAttribute("data-disabled-click")) return !1;
                    t.setAttribute("data-disabled-click", "1"), setTimeout(function() {
                        t.setAttribute("data-disabled-click", "")
                    }, 1e3), uLogin.startAuth(e, "", i)
                });
                else if ("window" === e && (this.ids[i].mobile || this.add(t, this.ids[i].event, function(t, e) {
                    if (e.preventDefault ? e.preventDefault() : e.returnValue = !1, /disabled/.test(t.className)) return !1;
                    var n = uLogin.buildUrl(uLogin.ids[i].mobile ? "version/3.0/html/mobile.html" : "version/3.0/html/window.html", {
                        id: i,
                        redirect_uri: uLogin.ids[i].redirect_uri,
                        callback: uLogin.ids[i].callback,
                        fields: uLogin.ids[i].fields,
                        force_fields: uLogin.ids[i].force_fields,
                        popup_css: uLogin.ids[i].popup_css,
                        optional: uLogin.ids[i].optional,
                        protocol: uLogin.protocol,
                        host: uLogin.host,
                        lang: uLogin.ids[i].lang,
                        verify: uLogin.ids[i].verify,
                        sort: uLogin.ids[i].sort,
                        othprov: uLogin.ids[i].hidden,
                        providers: uLogin.ids[i].providers,
                        altway: uLogin.ids[i].altway ? 1 : null,
                        m: uLogin.ids[i].m ? 1 : 0,
                        icons_32: uLogin.ids[i].icons_32,
                        icons_16: uLogin.ids[i].icons_16,
                        theme: uLogin.ids[i].theme,
                        client: uLogin.ids[i].client,
                        page: uLogin.page,
                        version: uLogin.version
                    });
                    return uLogin.loadWindow(n, i), !1
                }), t.getAttribute("data-ulogin-default"))) {
                var n = this.buildUrl("img/" + ("ru" == this.ids[i].lang ? "" : this.ids[i].lang + "/") + "button.png?version=img.3.0.1"),
                    o = this.buildUrl("img/" + ("ru" == this.ids[i].lang ? "" : this.ids[i].lang + "/") + "button_.png");
                t.src = n, this.resetStyle(t, {
                    cursor: "pointer"
                }), this.add(t, "mouseover", function(t) {
                    if (/disabled/.test(t.parentNode.className)) return !1;
                    t.src != o && (t.src = o)
                }), this.add(t, "mouseout", function(t) {
                    if (/disabled/.test(t.parentNode.className)) return !1;
                    t.src != n && (t.src = n)
                })
            }
        },
        randFromTo: function(t, i) {
            return Math.floor(Math.random() * i) + t
        },
        sendWeight: function(t) {
            this.initSocket(this.buildUrl("version/3.0/html/weight_set.html", {
                provider: t,
                r: parseInt(1e5 * Math.random())
            }), this.getRC(), {
                background: "transparent"
            })
        },
        setWeights: function(t) {
            this.supportStorage && (localStorage.providers_weight = t)
        },
        getWeights: function() {
            try {
                return JSON.parse(localStorage.providers_weight)
            } catch (t) {
                return {}
            }
        },
        relProviders: function(t, i, e) {
            if (t = t.split(","), i = i.split(","), this.supportStorage) {
                var n, o = this.getWeights();
                for (n in o) {
                    o = this.inArray(n, t);
                    var s = this.inArray(n, i); - 1 !== o ? (t.splice(o, 1), t.splice(0, 0, n)) : -1 !== s && (t.splice(0, 0, n), i.splice(s, 1), i.splice(0, 0, t[t.length - 1]), t.splice(t.length - 1, 1))
                }
            }
            return 1 === e ? t : i
        },
        startAuth: function(i, e, n) {
            var o = {
                name: i,
                window: 1,
                lang: this.ids[n].lang,
                fields: this.ids[n].fields,
                force_fields: this.ids[n].force_fields,
                popup_css: this.ids[n].popup_css,
                host: this.host,
                optional: this.ids[n].optional,
                redirect_uri: this.ids[n].redirect_uri || location.href,
                verify: this.ids[n].verify,
                callback: this.ids[n].callback,
                screen: screen.width + "x" + screen.height,
                url: e,
                providers: this.ids[n].providers,
                hidden: this.ids[n].hidden,
                m: this.ids[n].m ? 1 : 0,
                page: this.page,
                icons_32: this.ids[n].icons_32,
                icons_16: this.ids[n].icons_16,
                theme: this.ids[n].theme,
                client: this.ids[n].client,
                version: this.version
            };
            this.ids[n].altway && (o.altway = 1), i = e || "webmoney" != i && "livejournal" != i && "openid" != i ? this.buildUrl("auth.php", o) : this.buildUrl("url.php", o), this._changeState(n, this.states[1]), this.ids[n].altway ? t.top ? t.top.location.href = i : location.href = i : this.openWithReceiver(i, n)
        },
        openWithReceiver: function(t, i) {
            !i && (i = 0);
            var e = 660,
                n = 420;
            /name=vkontakte/.test(t) ? n = 380 : /name=facebook/.test(t) ? (e = 560, n = 350) : /name=google/.test(t) ? (e = 800, n = 630) : /name=yandex/.test(t) ? (e = 990, n = 530) : /name=lastfm/.test(t) && (e = 1368, n = 894), this.openFromSocket ? this.authSocket.postMessage("window.open::" + t + "::" + e + "::" + n + "::" + (screen.width - e) / 2 + "::" + (screen.height - n) / 2) : (this.initSocket(this.buildUrl("/version/3.0/html/buttons_receiver.html", {
                four: encodeURIComponent(t),
                r: parseInt(1e5 * Math.random())
            }), this.getRC(), {
                background: "transparent"
            }, i), uLogin.getRC().getElementsByTagName("iframe"), window.open(t, "uLogin_window", "width=" + e + ",height=" + n + ",left=" + (screen.width - e) / 2 + ",top=" + (screen.height - n) / 2))
        },
        checkWindow: function(t, i) {},
        checkCurrentWidgets: function() {
            for (var t = 0; this.ids[t];) this.checkWidget(this.ids[t++].id)
        },
        checkWidget: function(t, i) {
            var e = this.get(t);
            if (e)
                if (this.inited(t)) {
                    var n = this.getWidgetNumber(t),
                        o = this.ids[n].type;
                    if (("small" === o || "panel" === o) && !e.childNodes.length) return e = this.ids[n].id, uLogin.ids[n].id = !1, uLogin.initWidget(e), !0;
                    e.getAttribute("data-ulogin-inited") || (e = this.ids[n].id, uLogin.ids[n].id = !1, uLogin.initWidget(e))
                } else this.addWidget(this.get(t), i);
            else this.ids[this.getWidgetNumber(t)].id = !1
        },
        buildUrl: function(t, i, e) {
            i || (i = {}), e || (e = !1), t = t ? "https://" + this.uLoginHost + "/" + t : "";
            var n, o = "";
            for (n in i) {
                var s = i[n];
                null !== s && (!e && (/\?/.test(s) || /\//.test(s) || /:/.test(s)) && (s = ""), o += n + "=" + s + "&")
            }
            return 0 < o.length && (o = o.substring(0, o.length - 1), t = t + (/\?/.test(t) ? "&" : "?") + o), t
        },
        getWidget: function(t, e) {
            if (this.inited(e)) return !1;
            if (this.widgetSettings[t]) return this.setProp(e, uLogin.ids.length, this.widgetSettings[t]), !1;
            if (this.waitGetWidget[t] && -1 !== this.inArray(e, this.waitGetWidget[t])) return !1;
            if (this.waitGetWidget[t] || (this.waitGetWidget[t] = []), this.waitGetWidget[t].push(e), this.widgetSettings[t]) this.setProp(e, this.ids.length, this.widgetSettings[t]);
            else {
                var n = this.getRC(),
                    o = i.createElement("script");
                o.async = !0, o.src = this.buildUrl("getwidget", {
                    widgetid: t
                }), n.appendChild(o)
            }
        },
        forElements: function(t, i) {
            if (t && t.length)
                for (var e in t) i(t[e])
        },
        setWidget: function(t, e, n) {
            if (!n && e && (n = e), "not_found" === t) return this.forElements(this.waitGetWidget[t], function(t) {
                if ("string" != typeof t) return !1;
                i.getElementById(t).setAttribute("data-uloginid", "")
            }), !1;
            n && !uLogin.widgetSettings[t] && void 0 !== n.display && (this.forElements(this.waitGetWidget[t], function(t) {
                if ("string" != typeof t) return !1;
                var e = i.getElementById(t);
                if (!e) return console.error('uLogin ERROR: not found element with id "' + t + '"'), !1;
                for (var o in e = uLogin.parse(e.getAttribute("data-ulogin"))) n[o] = e[o];
                uLogin.setProp(t, uLogin.ids.length, n)
            }), this.widgetSettings[t] = n)
        },
        customInit: function() {
            for (var t = 0; t < arguments.length; t++)
                if ("string" == typeof arguments[t]) {
                    var i = !1;
                    if (!uLogin.get(arguments[t]) || !arguments[t]) return console.error('uLogin ERROR (customInit): Element with ID="' + arguments[t] + '" not found'), !1;
                    1 < arguments.length && "object" == typeof arguments[arguments.length - 1] && (i = arguments[arguments.length - 1]), uLogin.checkWidget(arguments[t], i)
                }
        },
        getOffsetSum: function(t) {
            for (var i = 0, e = 0; t;) i += parseFloat(t.offsetTop), e += parseFloat(t.offsetLeft), t = t.offsetParent;
            return {
                top: Math.round(i),
                left: Math.round(e)
            }
        },
        getOffsetRect: function(t) {
            t = t.getBoundingClientRect();
            var i = document.body,
                e = document.documentElement;
            return {
                top: Math.round(t.top + (window.pageYOffset || e.scrollTop || i.scrollTop) - (e.clientTop || i.clientTop || 0)),
                left: Math.round(t.left + (window.pageXOffset || e.scrollLeft || i.scrollLeft) - (e.clientLeft || i.clientLeft || 0))
            }
        },
        getOffset: function(t) {
            return t.getBoundingClientRect ? this.getOffsetRect(t) : this.getOffsetSum(t)
        },
        checkAsyncWidgets: function() {
            var t = this.get("ulogin") || this.get("uLogin");
            t && t.id && this.addWidget(t)
        },
        setStateListener: function(t, i, e) {
            return this.listeners[t] || (this.listeners[t] = {}), this.listeners[t][i] || (this.listeners[t][i] = []), this.listeners[t][i].push(e) - 1
        },
        removeStateListener: function(t, i, e) {
            return !(!this.listeners[t] || !this.listeners[t][e]) && this.listeners[t][e].splice(i, 1)
        },
        _changeState: function(i, e, n) {
            try {
                this.ids[i].state = e;
                for (var o = 0; this.listeners[this.ids[i].id][e][o];) this.listeners[this.ids[i].id][e][o++].apply(t, "object" == typeof n ? n : [])
            } catch (t) {}
        },
        extend: function(t, i) {
            for (var e in i) t[e] = i[e];
            return t
        },
        arrayIntersectKey: function(t, i) {
            var e, n = [];
            for (e in t) e in i && n.push(e);
            return n
        }
    }, -1 == uLogin.inArray(uLogin.lang, uLogin.langs) && (uLogin.lang = uLogin.langs[0]), uLogin.init("undefined" != typeof uLogin_query ? uLogin_query : "")), t.receiver = function(i, e, n) {
        uLogin._changeState(0, "receive", [i]), !n && e && (n = e), t[n](i)
    }, t.redirect = function(t, e) {
        var n = i.createElement("form");
        n.action = e, n.method = "post", n.target = "_top", n.style.display = "none";
        var o = i.createElement("input");
        o.type = "hidden", o.name = "token", o.value = t, n.appendChild(o), i.body.appendChild(n), n.submit()
    }
}(window, document, navigator, setTimeout);