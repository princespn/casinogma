;
(function() {
    const sortItem = $('.gamessort');
    let sortKey = 'popular'; /* TODO: Change if need */
    let sortOrder = 'descending'; /* `descending`  or `ascending` */
    let prevOffset = $('.all-games__list').find('.card').length;

    function getCardsQuantity() {
        var cardsRows = 3;
        var cardsColsMapOfWidth = [
            /* width, quantity cards on row*/
            [768, 6],
            [430, 2],
            [0, 1],
        ];

        var cardsQuantityOnRow = 0;

        cardsColsMapOfWidth.find(keyValue => {
            var minWidth = keyValue[0];
            var quantityOnRow = keyValue[1];

            if (window.innerWidth >= minWidth) {
                cardsQuantityOnRow = quantityOnRow;
                return quantityOnRow;
            }
        });

        return cardsQuantityOnRow * cardsRows;
    }

    function sortGames(options) {
        $('.all-games__list').map(function() {
            $(this).find('.card').sort(function(next, prev) {
                const sortResult = sortByKeys[options.sortKey](next, prev, options.sortKey);

                return options.sortOrder === 'descending' ? sortResult : sortResult * -1;
            }).detach().appendTo(this);
        });
    }

    function sortByName(next, prev) {
        return $(next).data().name.localeCompare($(prev).data().name);
    }

    function sortByPopular(next, prev) {
        let compare = $(prev).data().popular - $(next).data().popular;

        if (compare === 0) {
            return sortByName(next, prev);
        }

        return compare;
    }

    function sortByDate(next, prev) {
        let compare = $(prev).data().new - $(next).data().new;

        if (compare === 0) {
            return sortByName(next, prev);
        }

        return compare;
    }

    function handleClickMore(n) {
        const limit = getCardsQuantity();
        $.ajax({
            url: '/core/games/',
            type: 'POST',
            data: {
                type: n,
                limit: getCardsQuantity(),
                offset: prevOffset
            },
            success: function(response) {
                prevOffset += limit;
                if (n == 0) {
                    allgid = 'allgames';
                } else {
                    allgid = 'allslots';
                }
                $('#' + allgid).append(response);
                sortGames({
                    sortKey: sortKey,
                    sortOrder: sortOrder
                });
            },
            error: function(error) {
                console.error(error);
            },
        });
    }

    const sortByKeys = {
        name: sortByName,
        popular: sortByPopular,
        date: sortByDate,
    };

    sortItem.on('click', function(e) {
        e.preventDefault();
        const $this = $(this);
        sortItem.removeClass('active');
        $this.addClass('active');
        $this.parents('.section-3__list_item').find('.sort-label').text($this.text());

        const newSortKey = $this.data('key');
        sortOrder =
            sortKey === newSortKey && sortOrder === 'descending' ?
            'ascending' :
            'descending';

        sortGames({
            sortKey: newSortKey,
            sortOrder
        });

        sortKey = newSortKey;
    });

    $('#moregames').on('keyup click', function() {
        handleClickMore(0);
    });
    $('#moreslots').on('keyup click', function() {
        handleClickMore(1);
    });
}());