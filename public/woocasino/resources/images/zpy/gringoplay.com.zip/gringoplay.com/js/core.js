function getCookie(name) {
    var cookie = "" + document.cookie,
        search = "" + name + "=",
        setStr = null,
        offset = 0,
        end = 0;
    if (cookie.length > 0) {
        offset = cookie.indexOf(search);
        if (offset != -1) {
            offset += search.length;
            end = cookie.indexOf(";", offset);
            if (end == -1) {
                end = cookie.length;
            }
            setStr = unescape(cookie.substring(offset, end));
        }
    }
    return setStr;
}
$(function() {
    $.showerror = function(position, message) {
        $("#" + position).html(message);
    };
});

function balance() {
    $.ajax({
        type: "POST",
        url: "/core/balance/",
        data: {
            js: 1
        },
        cache: false,
        success: function(data) {
            $(".balancerefr").text(data);
        },
    });
}

function signup() {
    $.ajax({
        beforeSend: function() {
            $("#sig_button").prop("disabled", true);
        },
        complete: function() {
            $("#sig_button").prop("disabled", false);
        },
        type: "POST",
        url: "/core/ajax/signup/",
        data: {
            js: 1,
            user: "",
            email: $("#sig_email").val(),
            phone: "",
            pass: $("#sig_pass").val(),
            currency: $("#sig_currency").val(),
            gift: "",
            promo: $("#sig_promo").val(),
        },
        cache: false,
        error: function() {
            alert("Error!");
        },
        success: function(data) {
            try {
                data = JSON.parse(data);
                if (data) {
                    position = data.split("|")[0];
                    message = data.split("|")[1];
                    $.showerror(position, message);
                    rederror = data.split("|")[2];
                    $("#" + rederror).addClass("error");
                } else {
                    if (getCookie("lng") == "EN") {
                        location.replace("/en/");
                    } else {
                        location.replace("/");
                    }
                }
            } catch (e) {
                alert("Error!");
            }
        },
    });
}

function finish() {
    $.ajax({
        beforeSend: function() {
            $("#fin_button").prop("disabled", true);
        },
        complete: function() {
            $("#fin_button").prop("disabled", false);
        },
        type: "POST",
        url: "/core/ajax/finish/",
        data: {
            js: 1,
            email: $("#fin_email").val(),
            phone: $("#fin_phone").val(),
            currency: $("#fin_currency").val(),
            gift: $("#fin_gift").val(),
            news: 1,
            terms: 1,
        },
        cache: false,
        error: function() {
            alert("Error!");
        },
        success: function(data) {
            try {
                data = JSON.parse(data);
                if (data) {
                    position = data.split("|")[0];
                    message = data.split("|")[1];
                    $.showerror(position, message);
                } else {
                    if (getCookie("lng") == "EN") {
                        location.replace("/en/");
                    } else {
                        location.replace("/");
                    }
                }
            } catch (e) {
                alert("Error!");
            }
        },
    });
}

function uloginLink(token) {
    $.getJSON(
        "//ulogin.ru/token.php?host=" +
        encodeURIComponent(location.toString()) +
        "&token=" +
        token +
        "&callback=?",
        function(udata) {
            udata = $.parseJSON(udata.toString());
            if (!udata.error) {
                $.ajax({
                    type: "POST",
                    url: "/core/ajax/soclink.php",
                    data: {
                        js: 1,
                        profile: udata.profile,
                        network: udata.network,
                        identity: udata.identity,
                    },
                    cache: false,
                    error: function(errResponse) {
                        var errText = JSON.parse(errResponse.responseText);
                        Swal.fire({
                            icon: "error",
                            text: errText,
                            confirmButtonColor: "#55c12f",
                            background: "rgba(26,29,38,0.9)",
                        });
                    },
                    success: function(data) {
                        try {
                            data = JSON.parse(data);
                            Swal.fire({
                                icon: "success",
                                text: data,
                                confirmButtonColor: "#55c12f",
                                background: "rgba(26,29,38,0.9)",
                            });
                        } catch (e) {
                            alert("Error!" + " [" + e.message + "]");
                        }
                    },
                });
            }
        }
    );
}

function ulogin(token) {
    $.getJSON(
        "//ulogin.ru/token.php?host=" +
        encodeURIComponent(location.toString()) +
        "&token=" +
        token +
        "&callback=?",
        function(udata) {
            udata = $.parseJSON(udata.toString());
            if (!udata.error) {
                $.ajax({
                    type: "POST",
                    url: "/socsign/",
                    data: {
                        js: 1,
                        currency: $("#sig_currency").val(),
                        email: udata.email,
                        phone: udata.phone,
                        profile: udata.profile,
                        network: udata.network,
                        identity: udata.identity,
                    },
                    cache: false,
                    error: function() {
                        alert("Error!");
                    },
                    success: function(data) {
                        try {
                            data = JSON.parse(data);
                            status = data.split("|")[0];
                            message = data.split("|")[1];
                            if (status === 'error') {
                                Swal.fire({
                                    icon: "error",
                                    text: message,
                                    confirmButtonText: "OK",
                                    confirmButtonColor: "#55c12f",
                                    background: "rgba(26,29,38,0.9)",
                                });
                            } else {
                                if (getCookie("lng") == "EN") {
                                    location.replace("/en/");
                                } else {
                                    location.replace("/");
                                }
                            }
                        } catch (e) {
                            alert("Error!" + " [" + e.message + "]");
                        }
                    },
                });
            }
        }
    );
}

function login() {
    $.ajax({
        beforeSend: function() {
            $("#log_button").prop("disabled", true);
        },
        complete: function() {
            $("#log_button").prop("disabled", false);
        },
        type: "POST",
        url: "/core/ajax/login/",
        data: {
            js: 1,
            email: $("#log_email").val(),
            user: $("#log_user").val(),
            phone: $("#log_phone").val(),
            pass: $("#log_pass").val(),
        },
        cache: false,
        error: function() {
            alert("Error!");
        },
        success: function(data) {
            try {
                data = JSON.parse(data);
                if (data) {
                    position = data.split("|")[0];
                    message = data.split("|")[1];
                    $.showerror(position, message);
                    rederror = data.split("|")[2];

                    $("#" + rederror).addClass("error");
                } else {
                    if (getCookie("lng") == "EN") {
                        location.replace("/en/");
                    } else {
                        location.replace("/");
                    }
                }
            } catch (e) {
                alert("Error!");
            }
        },
    });
}

function restore() {
    $.ajax({
        beforeSend: function() {
            $("#res_button").prop("disabled", true);
        },
        complete: function() {
            $("#res_button").prop("disabled", false);
        },
        type: "POST",
        url: "/core/ajax/restore/",
        data: {
            js: 1,
            email: $("#res_email").val(),
            phone: $("#res_phone").val(),
            user: $("#res_user").val(),
        },
        cache: false,
        error: function() {
            alert("Error!");
        },
        success: function(data) {
            try {
                data = JSON.parse(data);
                if (data) {
                    position = data.split("|")[0];
                    message = data.split("|")[1];
                    $.showerror(position, message);
                    rederror = data.split("|")[2];

                    $("#" + rederror).addClass("error");
                }
            } catch (e) {
                alert("Error!");
            }
        },
    });
}

/*
function jackpot(){ $.ajax({
type: 'POST',
url: '/core/jackpot/',
cache: false,
success: function(data){
try{ data=JSON.parse(data);
if(data){
$('#jackpot1').text(data.split('|')[0]);
$('#jackpot2').text(data.split('|')[1]);
$('#jackpot3').text(data.split('|')[2]);

} }
catch (e){ alert('Error!'); } } }); }*/

function withdraw() {
    $.ajax({
        beforeSend: function() {
            $("#wit_button").prop("disabled", true);
        },
        complete: function() {
            $("#wit_button").prop("disabled", false);
        },
        type: "POST",
        url: "/core/ajax/withdraw/",
        data: {
            js: 1,
            amount: $("#wit_amount").val(),
            system: $("#wit_system").val(),
            account: $("#wit_account").val(),
        },
        cache: false,
        error: function(e) {
            Swal.fire({
                icon: "error",
                text: e.message,
                confirmButtonText: "OK",
                confirmButtonColor: "#55c12f",
                background: "rgba(26,29,38,0.9)",
            });
        },
        success: function(data) {
            try {
                data = JSON.parse(data);
                if (data) {
                    position = data.split("|")[0];
                    message = data.split("|")[1];
                    $.showerror(position, message);
                    rederror = data.split("|")[2];
                    $("#" + rederror).addClass("error");
                    if (position == "error") {
                        Swal.fire({
                            icon: "error",
                            text: message,
                            confirmButtonText: "OK",
                            confirmButtonColor: "#55c12f",
                            background: "rgba(26,29,38,0.9)",
                        });
                    }
                } else {
                    if (getCookie("lng") == "EN") {
                        location.replace("/en/");
                    } else {
                        location.replace("/");
                    }
                }
            } catch (e) {
                Swal.fire({
                    icon: "error",
                    text: e.message,
                    confirmButtonText: "OK",
                    confirmButtonColor: "#55c12f",
                    background: "rgba(26,29,38,0.9)",
                });
            }
        },
    });
}

function points() {
    $.ajax({
        type: "POST",
        url: "/core/points/",
        data: {
            js: 1,
            cp_sum: $("#cp_sum").val(),
        },
        cache: false,
        error: function() {
            alert("Error!");
        },
        success: function(data) {
            try {
                data = JSON.parse(data);
                if (data) {
                    position = data.split("|")[0];
                    message = data.split("|")[1];
                    $.showerror(position, message);
                }
            } catch (e) {
                alert("Error!");
            }
        },
    });
}

function profile() {
    if ($("#pro_phone").val() && !$("#pro_country_code").val()) {
        let text = cooklang == "EN" ? "Select a country" : "Выберите страну";
        Swal.fire({
            icon: "info",
            text: text,
            confirmButtonText: "OK",
            confirmButtonColor: "#55c12f",
            background: "rgba(26,29,38,0.9)",
        });
    } else {
        $.ajax({
            beforeSend: function() {
                $("#pro_button").prop("disabled", true);
            },
            complete: function() {
                $("#pro_button").prop("disabled", false);
            },
            type: "POST",
            url: "/core/ajax/profile/",
            data: {
                js: 1,
                email: $("#pro_email").val(),
                phone: $("#pro_country_code").val() + $("#pro_phone").val(),
                name: $("#pro_name").val(),
                country: $("#pro_country").val(),
                county: $("#pro_county").val(),
                bday: $("#pro_bday").val(),
                bmonth: $("#pro_bmonth").val(),
                byear: $("#pro_byear").val(),
            },
            cache: false,
            error: function(data) {
                alert("Error!" + data);
            },
            success: function(data) {
                try {
                    data = JSON.parse(data);
                    if (data) {
                        position = data.split("|")[0];
                        message = data.split("|")[1];
                        Swal.fire({
                            icon: "info",
                            text: message,
                            confirmButtonText: "OK",
                            confirmButtonColor: "#55c12f",
                            background: "rgba(26,29,38,0.9)",
                        });
                    }
                } catch (e) {
                    alert("Error!" + e.message);
                }
            },
        });
    }
}

function settings() {
    $.ajax({
        type: "POST",
        url: "/core/settings/",
        data: {
            js: 1,
            set_pas: $("#set_pas").val(),
            set_new: $("#set_new").val(),
            set_dep: $("#set_dep").val(),
            set_car: $("#set_car").val(),
            set_bon: $("#set_bon").val(),
            set_nws: $("#set_nws").val(),
        },
        cache: false,
        error: function() {
            alert("Error!");
        },
        success: function(data) {
            try {
                data = JSON.parse(data);
                if (data["text"]) {
                    $("#st_error").html("");
                    $("#" + data["where"]).html(data["text"]);
                }
            } catch (e) {
                alert("Error!");
            }
        },
    });
}

function support() {
    $.ajax({
        type: "POST",
        url: "/core/support/",
        data: {
            js: 1,
            sup_nam: $("#sup_nam").val(),
            sup_con: $("#sup_con").val(),
            sup_mes: $("#sup_mes").val(),
        },
        cache: false,
        error: function() {
            alert("Error!");
        },
        success: function(data) {
            try {
                data = JSON.parse(data);
                if (data["text"]) {
                    position = data.split("|")[0];
                    message = data.split("|")[1];
                    $.showerror(position, message);
                }
            } catch (e) {
                alert("Error!");
            }
        },
    });
}

$("#bon_act_button").on("keyup click", function() {
    $.ajax({
        beforeSend: function() {
            $("#bon_act_button").prop("disabled", true);
        },
        complete: function() {
            $("#bon_act_button").prop("disabled", false);
        },
        type: "POST",
        url: "/core/bonus/",
        data: {
            js: 1,
            bid: $("#bonactid").val(),
            bact: 1,
        },
        cache: false,
        error: function() {
            alert("Error!");
        },
        success: function(data) {
            try {
                data = JSON.parse(data);
                if (data) {
                    $("#bon_act_button").hide();
                    $("#bon_act_txt").html(data);
                }
            } catch (e) {
                alert("Error!");
            }
        },
    });
});

function jivo_onLoadCallback() {
    window.jivo_cstm_widget = document.createElement("div");
    jivo_cstm_widget.setAttribute("id", "jivo_custom_widget");
    document.body.appendChild(jivo_cstm_widget);
    jivo_cstm_widget.onclick = function() {
        jivo_api.open();
    };
    if (jivo_config.chat_mode == "online") {
        jivo_cstm_widget.setAttribute("class", "jivo_online");
    }
    window.jivo_cstm_widget.style.display = "block";
}

$(document).ready(function() {
    $(".notification_close").click(function() {
        console.log(1);
        $(this).parents(".notification_block").remove();
        thiseidnc = $(this).data("value");
        $.ajax({
            type: "POST",
            url: "/core/event/",
            data: {
                eid: thiseidnc,
                act: 1
            },
            cache: false,
        });
    });

    $(".noread.notification_block").mouseenter(function() {
        console.log(2);
        $(this).removeClass("noread");
        thiseidrd = $(this).data("value");
        $.ajax({
            type: "POST",
            url: "/core/event/",
            data: {
                eid: thiseidrd,
                act: 2
            },
            cache: false,
        });
    });

    const scrollWidth = window.innerWidth - document.documentElement.clientWidth;

    $.fancybox.defaults.beforeShow = function() {
        $(".header, .section-3.active").css({
            right: scrollWidth
        });
    };

    $.fancybox.defaults.afterClose = function() {
        $(".header, .section-3.active").css({
            right: ""
        });
        $("body").removeClass("dropdown-active");
    };

    $(".chatbutton").bind("keyup click", function() {
        jivo_api.open();
    });

    function likegames(a, b) {
        $.ajax({
            type: "POST",
            url: "/core/ajax/likegames/",
            data: {
                js: 1,
                gameid: a,
                action: b,
            },
            cache: false,
            error: function() {
                alert("Error!");
            },
            success: function(data) {
                try {} catch (e) {
                    alert("Error!");
                }
            },
        });
    }

    if (getCookie("user") !== null) {
        $(".likegame").on("keyup click", function() {
            var $this = $(this);
            gameid = $this.val();
            if ($this.prop("checked")) {
                likegames(gameid, 1);
            } else {
                likegames(gameid, 0);
            }
        });
    }

    let prevOffset = 18;

    function getCardsQuantity() {
        var cardsRows = 3;
        var cardsColsMapOfWidth = [
            [768, 6],
            [430, 2],
            [0, 1],
        ];

        var cardsQuantityOnRow = 0;

        cardsColsMapOfWidth.find((keyValue) => {
            var minWidth = keyValue[0];
            var quantityOnRow = keyValue[1];

            if (window.innerWidth >= minWidth) {
                cardsQuantityOnRow = quantityOnRow;
                return quantityOnRow;
            }
        });

        return cardsQuantityOnRow * cardsRows;
    }

    function checkamountpay() {
        pregsum = $("#wit_amount")
            .val()
            .replace(/[^\d.]/gi, "");
        $("#wit_amount").val(pregsum);
        amount = Number($("#wit_amount").val());
        minwithdraw = Number($("#minwithdraw").text());
        maxwithdraw = Number($("#maxwithdraw").text());
        if (amount < minwithdraw || amount > maxwithdraw) {
            $("#wit_button").attr("disabled", true);
            $("#wit_button").css({
                opacity: "0.7"
            });
            $("#wit_amount").css({
                color: "#ff0000"
            });
        } else {
            $("#wit_button").attr("disabled", false);
            $("#wit_button").css({
                opacity: "1"
            });
            $("#wit_amount").css({
                color: "#fff"
            });
        }
    }

    function checkamount() {
        pregsum = $("#dep_amount")
            .val()
            .replace(/[^\d.]/gi, "");
        $("#dep_amount").val(pregsum);
        amount = Number($("#dep_amount").val());
        mindeposit = Number($("#mindeposit").text());
        maxdeposit = Number($("#maxdeposit").text());
        if (amount < mindeposit || amount > maxdeposit) {
            $("#dep_button").attr("disabled", true);
            $("#dep_button").css({
                opacity: "0.7"
            });
            $("#dep_amount").css({
                color: "#ff0000"
            });
        } else {
            $("#dep_button").attr("disabled", false);
            $("#dep_button").css({
                opacity: "1"
            });
            $("#dep_amount").css({
                color: "#fff"
            });
        }
    }

    $("#dep_phone").on("keyup click change input", function() {
        $this = $(this);
        systemphone = $("#payway").val();
        newValue = $this.val().replace(/[^0-9]/g, "");
        if (
            systemphone == "qiwi_rub" ||
            systemphone == "qiwi_usd" ||
            systemphone == "qiwi_eur"
        ) {
            newValue = newValue.substr(0, 12);
        } else {
            if (newValue[0] != "9") {
                newValue = ("9" + newValue).substr(0, 10);
            }
            if (newValue.length > 10) {
                newValue = ("9" + newValue).substr(0, 10);
            }
        }
        $this.val(newValue);
    });

    $("#dep_amount").on("keyup click change input", function() {
        checkamount();
    });
    $("#dep_coupon").on("keyup click change input", function() {
        $this = $(this);
        newValue = $this.val().replace(/[^0-9A-Za-z]/g, "");
        newValue2 = newValue.toUpperCase();
        $this.val(newValue2);
    });

    $("#dep_button").on("keyup click", function() {
        depositphone = $("#dep_phone").val();
        if (
            $("#dep_phone").attr("disabled") !== "disabled" &&
            depositphone.length < 10
        ) {
            var errText =
                cooklang == "EN" ?
                "Please check your phone number" :
                "Пожалуйста проверьте свой номер телефона";
            Swal.fire({
                icon: "error",
                text: errText,
                confirmButtonColor: "#55c12f",
                background: "rgba(26,29,38,0.9)",
            });
            return;
        }

        depositway = $("#payway").val();
        depositsum = $("#dep_amount").val();

        depositcoupon = $("#dep_coupon").val();

        if (
            depositway == "bitcoin" ||
            depositway == "cd" ||
            depositway == "qiwi_rub"
        ) {
            if (depositway == "qiwi_rub") {
                window.open(
                    "/pay/pay/?payway=" +
                    depositway +
                    "&amount=" +
                    depositsum +
                    "&coupon=" +
                    depositcoupon
                );
            }
            if (depositway == "cd") {
                window.open(
                    "/pay/pay/?payway=" +
                    depositway +
                    "&amount=" +
                    depositsum +
                    "&coupon=" +
                    depositcoupon
                );
            }
            if (depositway == "bitcoin") {
                window.open(
                    "/pay/crypto/?payway=" +
                    depositway +
                    "&amount=" +
                    depositsum +
                    "&coupon=" +
                    depositcoupon
                );
            }
        } else {
            if (depositphone == "") {
                window.open(
                    "/pay/index/?payway=" +
                    depositway +
                    "&amount=" +
                    depositsum +
                    "&coupon=" +
                    depositcoupon
                );
            } else {
                window.open(
                    "/pay/index/?payway=" +
                    depositway +
                    "&amount=" +
                    depositsum +
                    "&phone=" +
                    depositphone +
                    "&coupon=" +
                    depositcoupon
                );
            }
        }
        return false;
    });

    $("#paysystems .dropdown__content_list_item").on("keyup click", function() {
        var $this = $(this);
        paysystem = $this.data("value");
        $("#payway").val(paysystem);
        $("#mindeposit").text($this.data("mindeposit"));
        $("#maxdeposit").text($this.data("maxdeposit"));
        if (
            paysystem == "qiwi_rub" ||
            paysystem == "qiwi_usd" ||
            paysystem == "qiwi_eur" ||
            paysystem == "beeline_rub" ||
            paysystem == "mts_rub" ||
            paysystem == "megafon_rub" ||
            paysystem == "tele2_rub" ||
            paysystem == "blackrabbit_rub"
        ) {
            if (
                paysystem == "qiwi_rub" ||
                paysystem == "qiwi_usd" ||
                paysystem == "qiwi_eur"
            ) {
                if (getCookie("lng") == "EN") {
                    typephonedep = "Qiwi phone number without +";
                } else {
                    typephonedep = "Номер телефона Qiwi без +";
                }
            } else {
                if (getCookie("lng") == "EN") {
                    typephonedep = "Phone number without +7";
                } else {
                    typephonedep = "Номер телефона без +7";
                }
            }

            $("#dep_phone").attr("disabled", false);

            $("#dep_phone").attr("placeholder", typephonedep);
            $(".deposit .no-value").hide();
            $("#dep_phone").show();
            $("#dep_phone_form").removeClass("hiddenstyle");
            $("#dep_amount").show();
        } else {
            $("#dep_phone").attr("disabled", true);
            if (getCookie("lng") == "EN") {
                typephonedep = "No phone number required";
            } else {
                typephonedep = "Номер телефона не требуется";
            }
            $("#dep_phone").attr("placeholder", typephonedep);
            $(".deposit .no-value").hide();
            $("#dep_phone").show();
            $("#dep_amount").show();
            $("#dep_phone").val("");
            $("#dep_phone_form").addClass("hiddenstyle");
        }
        checkamount();
    });

    //setInterval(jackpot,3000);

    $("#witsystems .dropdown__content_list_item").on("keyup click", function() {
        var $this = $(this);
        paysystem = $this.data("value");
        $("#wit_system").val(paysystem);
        $("#minwithdraw").text($this.data("minwithdraw"));
        $("#maxwithdraw").text($this.data("maxwithdraw"));
    });

    $("#sig_button").on("keyup click", function() {
        signup();
    });

    $("#log_button").on("keyup click", function() {
        login();
    });

    $("#reg_button").on("keyup click", function() {
        signup();
    });

    $("#res_button").on("keyup click", function() {
        restore();
    });

    $("#wit_button").on("keyup click", function() {
        withdraw();
    });

    $("#pro_button").on("keyup click", function() {
        profile();
    });

    $(".playlink").on("keyup click", function() {
        url = $(this).val();
        $(location).attr("href", url);
    });

    function startTimer1() {
        setInterval(function() {
            if (timer1.seconds == 0) {
                timer1.seconds = 59;
                if (timer1.minutes == 0) {
                    timer1.minutes = 59;
                    if (timer1.hours == 0) {
                        timer1.hours = 23;
                        timer1.days--;
                    } else {
                        timer1.hours--;
                    }
                } else {
                    timer1.minutes--;
                }
            } else {
                timer1.seconds--;
            }
            rendertimer1();
        }, 1000);
        rendertimer1();
    }

    function rendertimer1() {
        $("#season .days").html((timer1.days < 10 ? "0" : "") + timer1.days);
        $("#season .hours").html((timer1.hours < 10 ? "0" : "") + timer1.hours);
        $("#season .min").html((timer1.minutes < 10 ? "0" : "") + timer1.minutes);
        $("#season .sec").html((timer1.seconds < 10 ? "0" : "") + timer1.seconds);
    }
    //$('#winners').css({'position':'relative','top':'-69px','margin-bottom':'-65px'});
    function wl_slide() {
        (function() {
            var wliH = $("#winners .third-top__item").innerHeight();
            $("#winners .third-top__item:last-child")
                .clone()
                .prependTo("#winners")
                .fadeOut(0)
                .fadeIn(0);
            $("#winners")
                .css({
                    position: "relative",
                    "padding-top": "0px",
                })
                .animate({
                    "padding-top": wliH + 4 + "px"
                }, 400);

            // function wlsDel() {
            $("#winners .third-top__item:last-child").remove();
            // }
            // setTimeout(wlsDel,400)
            // setInterval(wl_slide(),400)
            setTimeout(arguments.callee, 3000);
        })();
        // setTimeout(wl_slide2(),400)
    }
    wl_slide();

    $(".waitbonsactive").on("keyup click", function() {
        bid = $(this).data("value");
        if (bid > 0) {
            $("#bonactid").val(bid);
        }
    });

    $(".providers").on("keyup click", function() {
        brand = $(this).data("value");
        if (brand.length == 2) {
            $.ajax({
                type: "POST",
                url: "/core/sort/",
                data: {
                    sortquery: brand
                },
                cache: false,
                success: function(html) {
                    $("#games").html(html);
                },
            });
        }
    });

    $(".categories").on("keyup click", function() {
        brand = $(this).data("value");
        if (brand.length == 2) {
            $.ajax({
                type: "POST",
                url: "/core/sort/",
                data: {
                    sortquery: brand
                },
                cache: false,
                success: function(html) {
                    $("#games").html(html);
                },
            });
        }
    });

    $(".gametype").on("keyup click", function() {
        brand = $(this).data("value");
        if (brand.length == 3) {
            $.ajax({
                type: "POST",
                url: "/core/sort/",
                data: {
                    sortquery: brand
                },
                cache: false,
                success: function(html) {
                    $("#games").html(html);
                },
            });
        }
    });

    $(".games-box .games-nav__item").on("keyup click", function() {
        var $this = $(this);

        $(".games-box .games-nav__item").removeClass("active");

        if ($this.hasClass("active")) {
            $this.removeClass("active");
        } else {
            $this.addClass("active");
        }

        type = $(this).data("value");
        if (type.length > 1) {
            newtitle = $(this).text();
            $("#gamestitle").text(newtitle);

            $.ajax({
                type: "POST",
                url: "/core/sort/",
                data: {
                    sortquery: type
                },
                cache: false,
                success: function(html) {
                    $("#games").html(html);
                },
            });
        }
    });

    $("#gamesearch").on("keyup input change click", function() {
        searchquery = $(this).val();

        if (searchquery.length >= 2) {
            if (getCookie("lng") == "EN") {
                newtitle = "Search results";
            } else {
                newtitle = "Результаты поиска";
            }
            $("#gamestitle").text(newtitle);
            $.ajax({
                global: false,
                type: "POST",
                url: "/core/search/",
                data: {
                    searchquery: searchquery
                },
                cache: false,
                success: function(html) {
                    $("#searchgames").html(html);
                },
            });
        }
    });

    $(".sig_currency").on("keyup click", function() {
        currency = $(this).data("value");
        $("#sig_currency").val(currency);
    });

    $("#profile-year ul li a").on("keyup click", function() {
        $this = $(this).data("value");
        $("#pro_byear").val($this);
    });
    $("#profile-birthday ul li a").on("keyup click", function() {
        $this = $(this).data("value");
        $("#pro_bday").val($this);
    });
    $("#profile-month ul li a").on("keyup click", function() {
        $this = $(this).data("value");
        $("#pro_bmonth").val($this);
    });
    $("#profile-country ul li a").on("keyup click", function() {
        $this = $(this).data("value");
        $("#pro_country").val($this);
    });

    $("#log_button").on("keyup click", function() {
        $("#modal-login .input").removeClass("error");
        $("#modal-login .input").removeClass("success");
        $("#modal-login .label-error").text("");
        $("#modal-login .errortext").text("");
    });

    $("#res_button").on("keyup click", function() {
        $("#modal-recovery .input").removeClass("error");
        $("#modal-recovery .input").removeClass("success");
        $("#modal-recovery .errortext").text("");
        $("#modal-recovery .label-error").text("");
    });

    $("#reg_button, #sig_button").on("keyup click", function() {
        $("#modal-registration .input").removeClass("error");
        $("#modal-registration .input").removeClass("success");
        $("#modal-registration .errortext").text("");
        $("#modal-registration .label-error").text("");
    });

    $("#res_phone").on("keyup click", function() {
        $("#res_email").val("");
    });

    $("#res_email").on("keyup click", function() {
        $("#res_phone").val("");
    });

    $("#wit_amount").on("keyup click", function() {
        checkamountpay();
    });
    $(".modal-deposit__range_item").on("keyup click", function() {
        $("#dep_coupon").val($(this).data("promo"));
        $("#dep_amount").val($(this).data("value"));
        checkamount();
    });
});

function validatePasswordForm(form) {
    var oldPassword;
    var newPassword;
    var newPasswordRepeat;

    var chkRes = false;

    $.each($(form).serializeArray(), function(i, field) {
        var input = $("input[name=" + field.name + "]");
        if (
            $("#" + field.name).attr("required") == "required" &&
            field.value.length == 0
        ) {
            $("#" + field.name)
                .parent()
                .addClass("error");
            $("#" + field.name)
                .parent()
                .removeClass("success");
            $("#" + field.name)
                .parent()
                .find("span.label-error")
                .removeClass("hiddenstyle");
        } else {
            $("#" + field.name)
                .parent()
                .removeClass("error");
            $("#" + field.name)
                .parent()
                .addClass("success");
            $("#" + field.name)
                .parent()
                .find("span.label-error")
                .addClass("hiddenstyle");
        }

        if (String(field.name).includes("Password")) {
            switch (field.name) {
                case "newPassword":
                    newPassword = field.value;
                    break;
                case "newPasswordRepeat":
                    newPasswordRepeat = field.value;
                    break;
                case "oldPassword":
                    oldPassword = field.value;
                    break;
                default:
                    break;
            }
        }
    });

    let passNotMatchText =
        getCookie("lng") == "RU" ? "Пароли не совпадают" : "Passwords not match";
    if (newPassword && newPasswordRepeat && newPassword != newPasswordRepeat) {
        $("#newPasswordRepeat").parent().removeClass("success");
        $("#newPassword").parent().removeClass("success");
        $("#newPasswordRepeat").parent().addClass("error");
        $("#newPassword").parent().addClass("error");
        $("#newPasswordRepeat")
            .parent()
            .find("span.label-error")
            .html(passNotMatchText);
        $("#newPasswordRepeat")
            .parent()
            .find("span.label-error")
            .removeClass("hiddenstyle");
        chkRes = false;
    } else {
        $("#newPasswordRepeat").parent().removeClass("error");
        $("#newPassword").parent().removeClass("error");
        $("#newPasswordRepeat").parent().addClass("success");
        $("#newPassword").parent().addClass("success");
        $("#newPasswordRepeat")
            .parent()
            .find("span.label-error")
            .addClass("hiddenstyle");
        chkRes = true;
    }

    if (chkRes) {
        if (newPassword && newPasswordRepeat && newPassword == newPasswordRepeat) {
            $.ajax({
                type: "POST",
                url: "/core/ajax/profile.php",
                data: {
                    js: 1,
                    action: "changepassword",
                    newpassword: newPassword,
                    newpasswordrepeat: newPasswordRepeat,
                    oldpassword: oldPassword,
                },
                cache: false,
                success: function(data) {
                    resArray = [];
                    if (String(data).includes("|")) {
                        data = JSON.parse(data);
                        resArray = data.split("|");
                        var position = resArray[0];
                        var message = resArray[1];
                        $.showerror(position, message);
                        $("#" + position).addClass("error");
                        if (resArray[2] == "pro_curpass_err") {
                            $("#oldPassword").parent().removeClass("success");
                            $("#oldPassword").parent().addClass("error");
                        }
                    }
                },
            });
        }
    }

    return false;
}

$("#prc_button").click(function() {
    let coupon = $("#coupon").val();
    $.ajax({
        type: "POST",
        url: "/core/ajax/coupons.php",
        data: {
            js: 1,
            coupon: coupon,
        },
        cache: false,
        success: function(data) {
            data = JSON.parse(data);
            let resArray = data.split("|");
            let position = resArray[0];
            let message = resArray[1];
            let cssClass = resArray[2];
            $.showerror(position, message);
            $("#coupon").parents().find("label").addClass(cssClass);
        },
    });
});

$("#btnBonusesHistory").click((e) => {
    e.preventDefault();
    let fromDate = $("#hbonsstart").val();
    let toDate = $("#hbonsend").val();
    if (fromDate && toDate) {
        $.ajax({
            type: "POST",
            url: "/core/ajax/bonus.php",
            data: {
                js: 1,
                action: "history",
                from: fromDate,
                to: toDate
            },
            success: function(data) {
                $(".balance__table_body").html(data);
            },
        });
    }
});

$("#btnConvertCp").click((e) => {
    e.preventDefault();
    let text = cooklang == "EN" ? "Confirm converting" : "Подтвердите обмен";
    let confirmText = cooklang == "EN" ? "Confirm" : "Принять";
    let cancelText = cooklang == "EN" ? "Cancel" : "Отмена";
    let currCp = $("#cpBalance").html();
    if (currCp > 1000) {
        Swal.fire({
            icon: "question",
            text: text,
            showCancelButton: true,
            confirmButtonText: confirmText,
            confirmButtonColor: "#55c12f",
            background: "rgba(26,29,38,0.9)",
            cancelButtonText: cancelText,
        }).then(function(result) {
            if (result.isConfirmed == true) {
                $.ajax({
                    type: "POST",
                    url: "/core/ajax/bonus.php",
                    data: {
                        js: 1,
                        action: "convertcp"
                    },
                    success: function(data) {
                        let jsonData = JSON.parse(data);
                        let balance = jsonData.cash;
                        let cashDec = (balance % 1).toFixed(2);
                        cashDec = (cashDec + "").split(".")[1];
                        let cashInt = Math.trunc(balance);
                        $("#cpBalance").html(jsonData.cp);
                        $("#cashInt").html(cashInt);
                        $("#cashDec").html("." + cashDec);
                    },
                });
            }
        });
    } else {
        let text = cooklang == "EN" ? "Not enough diamonds" : "Не хватает алмазов";
        Swal.fire({
            icon: "info",
            text: text,
            confirmButtonText: "OK",
            confirmButtonColor: "#55c12f",
            background: "rgba(26,29,38,0.9)",
        });
    }
});

function setCountryCode(code) {
    $("#pro_country_code").val("+" + code);
}

function cancelBonus(id, confirmation = true) {
    let sendAjax = () =>
        $.ajax({
            type: "POST",
            url: "/core/ajax/bonus.php",
            data: {
                js: 1,
                action: "cancelbonus",
                bonusid: id
            },
            success: function(data) {
                let jsonData;
                try {
                    jsonData = JSON.parse(data);
                } catch (e) {
                    Swal.fire({
                        icon: "error",
                        title: "Oops...",
                        text: "Something went wrong!",
                        confirmButtonText: "OK",
                        confirmButtonColor: "#55c12f",
                        background: "rgba(26,29,38,0.9)",
                    });
                    return false;
                }

                Swal.fire({
                    icon: "info",
                    text: jsonData,
                    confirmButtonText: "OK",
                    confirmButtonColor: "#55c12f",
                    background: "rgba(26,29,38,0.9)",
                }).then(() => window.location.reload());
            },
        });

    if (!confirmation) {
        sendAjax();
        $.fancybox.close();
    } else {
        let text =
            cooklang == "EN" ?
            "Confirm Bonus Cancellation " :
            "Подтвердите отмену бонуса";
        let confirmText = cooklang == "EN" ? "Confirm" : "Подтвердить";
        let cancelText = cooklang == "EN" ? "Cancel" : "Отмена";
        Swal.fire({
            icon: "question",
            text: text,
            showCancelButton: true,
            confirmButtonText: confirmText,
            confirmButtonColor: "#55c12f",
            background: "rgba(26,29,38,0.9)",
            cancelButtonText: cancelText,
        }).then(function(result) {
            if (result.isConfirmed == true) {
                sendAjax();
            }
        });
    }
}

function fastDep(amount) {
    $("#dep_amount").val(amount);
    $("#dep_coupon").val("");
    let label = $(`.modal-deposit__range_item`);
    console.log(label);
}

function getTransactions() {
    let from = $("#from").val();
    let to = $("#to").val();
    if (from && to) {
        $.ajax({
            url: "/core/ajax/transactions.php",
            method: "POST",
            data: {
                js: 1,
                from: from,
                to: to
            },
            success: function(data) {
                $(".balance__table_body").html(data);
            },
        });
    }
    console.log("DATES", from, to);
}