<tr>
    <td><a href="{{ route('backend.sms_bonus.edit', $sms_bonus->id) }}">{{ $sms_bonus->days }}</a></td>
	<td>{{ $sms_bonus->bonus }}</td>
	<td>x{{ $sms_bonus->wager }}</td>


</tr>
