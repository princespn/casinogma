<tr>
    <td>{!! $stat['Game'] !!}</td>
    <td>{!! $stat['User'] !!}</td>
    <td>{!! $stat['Balance'] !!}</td>
    <td>{!! $stat['Bet'] !!}</td>
    <td>{!! $stat['Win'] !!}</td>
    <td>{!! $stat['IN_GAME'] !!}</td>
    <td>{!! $stat['IN_JPG'] !!}</td>
    <td>{!! $stat['Profit'] !!}</td>
    <td>{!! $stat['Slots'] !!}</td>
    <td>{!! $stat['Bonus'] !!}</td>
    <td>{!! $stat['Fish'] !!}</td>
    <td>{!! $stat['Table'] !!}</td>
    <td>{!! $stat['Little'] !!}</td>
    <td>{!! $stat['Total_bank'] !!}</td>
    <td>{!! date(config('app.date_time_format'), $stat['Date']) !!}</td>
</tr>