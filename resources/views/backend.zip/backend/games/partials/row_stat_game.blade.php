<tr>
	<td class="align-middle">{{ $stat->user->username }}</td>
	<td class="align-middle">{{ $stat->balance }}</td>
	<td class="align-middle">{{ $stat->bet }}</td>
	<td class="align-middle">{{ $stat->win }}</td>    
</tr>